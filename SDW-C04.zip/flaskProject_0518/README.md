# E-DBA (Education Data Bay Area)

A comprehensive education data sharing platform that enables secure data exchange between educational institutions in the Bay Area.

## Features

### User Management
- Multi-level user authentication system
  - T-Admin (Technical Administrator)
  - E-Admin (Education Administrator)
  - SE-Admin (Senior Education Administrator)
  - O-Convener (Organization Convener)
  - DataUser (Regular Data User)
- User registration with email verification
- Password reset functionality
- User profile management

### Organization Management
- Organization registration and approval workflow
- Workspace management for each organization
- Bank account configuration for payments
- API configuration management for external services

### Data Services
- Course information sharing and management
- Student identity authentication with photo verification
- Thesis access and sharing system
- GPA record access and management
- Secure data exchange between institutions

### Payment System
- Online payment integration
- Bank transfer functionality
- Payment record tracking
- Membership pricing management
- Payment quota system

### Security Features
- Secure data exchange protocols
- Activity logging and monitoring
- Role-based access control
- API authentication
- Data encryption

## Technical Stack

### Backend
- Flask 3.0.2
- SQLAlchemy 2.0.28
- Flask-Login for authentication
- Flask-Mail for email services
- Flask-Migrate for database migrations
- Flask-CORS for cross-origin support

### Database
- MySQL with PyMySQL
- SQLAlchemy ORM
- Database migrations support

### External Services
- Bank API integration
- Student authentication service
- GPA record service
- Email service

## Setup Instructions

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Create a `.env` file with the following configurations:
```
SECRET_KEY=your_secret_key
MAIL_SERVER=smtp.example.com
MAIL_PORT=587
MAIL_USERNAME=your_email@example.com
MAIL_PASSWORD=your_email_password
DATABASE_URL=mysql+pymysql://username:password@localhost:3306/e-dba
```

4. Initialize the database:
```bash
flask db init
flask db migrate
flask db upgrade
```

5. Run the application:
```bash
flask run
```

## Project Structure

```
flaskProject_0518/
├── models/
│   ├── user.py          # User models and authentication
│   └── workspace.py     # Workspace and organization models
├── routes/
│   ├── admin_bp.py      # Admin routes
│   ├── auth.py          # Authentication routes
│   ├── course_bp.py     # Course management routes
│   ├── datauser_bp.py   # Data user routes
│   └── oconvener_bp.py  # Organization convener routes
├── services.py          # External service integrations
├── templates/
│   ├── workspace/       # Workspace templates
│   └── auth/           # Authentication templates
├── utils/
│   └── activity_logger.py  # Activity logging utility
├── static/             # Static files
├── uploads/            # File upload directory
├── app.py             # Main application file
├── requirements.txt    # Project dependencies
└── README.md          # Project documentation
```

## API Documentation

### Authentication Endpoints
- `/api/auth/register` - User registration
- `/api/auth/login` - User login
- `/api/auth/reset-password` - Password reset

### Organization Endpoints
- `/api/organizations` - Organization management
- `/api/workspaces` - Workspace management
- `/api/bank-accounts` - Bank account management

### Data Service Endpoints
- `/api/courses` - Course management
- `/api/thesis` - Thesis management
- `/api/students` - Student data management
- `/api/gpa` - GPA record management

### Payment Endpoints
- `/api/payments` - Payment processing
- `/api/membership-pricing` - Pricing management

## Security Considerations

1. All API endpoints require authentication
2. Sensitive data is encrypted
3. Role-based access control is implemented
4. Activity logging for audit trails
5. Secure file upload handling
6. Input validation and sanitization

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License. 