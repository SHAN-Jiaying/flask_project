from datetime import datetime, timedelta
from models.workspace import ActivityLog, db
from models.user import users

def log_activity(workspace_id, user_id, activity_type, details):
    """
    Log an activity in the workspace
    
    Args:
        workspace_id (int): The ID of the workspace
        user_id (int): The ID of the user performing the action
        activity_type (str): Type of activity (e.g., 'course', 'thesis', 'auth', 'help')
        details (dict): Additional details about the activity
    """
    try:
        activity_log = ActivityLog(
            workspace_id=workspace_id,
            user_id=user_id,
            activity_type=activity_type,
            details=details,
            timestamp=datetime.utcnow()
        )
        db.session.add(activity_log)
        db.session.commit()
        return True
    except Exception as e:
        print(f"Error logging activity: {str(e)}")
        db.session.rollback()
        return False

def get_activity_logs(workspace_id, filters=None):
    """
    Get activity logs for a workspace with optional filters
    
    Args:
        workspace_id (int): The ID of the workspace
        filters (dict): Optional filters for activity type, username, date
    
    Returns:
        list: List of activity logs
    """
    try:
        # Start with base query
        query = ActivityLog.query.join(
            users, ActivityLog.user_id == users.id
        ).filter(
            ActivityLog.workspace_id == workspace_id
        )

        # Apply filters if provided
        if filters:
            if filters.get('activity_type'):
                query = query.filter(ActivityLog.activity_type == filters['activity_type'])
            if filters.get('username'):
                query = query.filter(users.user_name.ilike(f"%{filters['username']}%"))
            if filters.get('date'):
                date = datetime.strptime(filters['date'], '%Y-%m-%d')
                query = query.filter(
                    ActivityLog.timestamp >= date,
                    ActivityLog.timestamp < date + timedelta(days=1)
                )

        # Execute query and format results
        logs = query.order_by(ActivityLog.timestamp.desc()).all()
        
        return [{
            'username': users.query.get(log.user_id).user_name,
            'activity_type': log.activity_type,
            'details': log.details,
            'timestamp': log.timestamp.isoformat()
        } for log in logs]

    except Exception as e:
        print(f"Error retrieving activity logs: {str(e)}")
        return [] 