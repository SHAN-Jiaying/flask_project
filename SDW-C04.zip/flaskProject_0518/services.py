from models.workspace import APIConfig, Workspace
from models.user import RegistrationApplication, OConvener, db
from datetime import datetime
import pandas as pd
from flask import jsonify, request
from werkzeug.datastructures import FileStorage
import requests
import os

def get_api_config(service_type, workspace_id):
    """根据服务类型和机构ID获取配置"""
    return APIConfig.query.filter_by(
        service_type=service_type,
        workspace_id=workspace_id
    ).first()

def call_external_api(service_type, workspace_id, params):
    """调用外部API"""
    try:
        # 获取API配置
        api_config = get_api_config(service_type, workspace_id)
        if not api_config:
            return {
                'status': 'error',
                'error_type': '配置错误',
                'details': ['未找到API配置']
            }

        # 构建请求URL
        url = f"{api_config.base_url}{api_config.path}"
        print(f"\n=== API Request Details ===")
        print(f"Request URL: {url}")
        print(f"Service Type: {service_type}")
        print(f"Workspace ID: {workspace_id}")
        print(f"API Config: {api_config.__dict__}")
        
        # 设置请求头
        headers = {
            'Accept': 'application/json'
        }
        print(f"Request Headers: {headers}")

        # 处理论文搜索服务
        if service_type == 'thesis_search':
            keywords = params.get('keywords')
            if not keywords:
                return {
                    'status': 'error',
                    'error_type': '参数验证失败',
                    'details': ['缺少必要参数: keywords']
                }

            # 准备请求数据
            request_data = {
                'keywords': keywords
            }
            print(f"\n=== Request Body ===")
            print(f"Request Data: {request_data}")

            # 发送POST请求
            print("\n=== Sending Request ===")
            response = requests.post(url, json=request_data, headers=headers)
            print(f"Response Status Code: {response.status_code}")
            print(f"Response Headers: {dict(response.headers)}")
            print(f"Response Content: {response.text}")
            
            # 处理响应
            if response.status_code == 200:
                try:
                    result = response.json()
                    print(f"\n=== Response Data ===")
                    print(f"Parsed Response: {result}")
                    return {
                        'status': 'success',
                        'data': result
                    }
                except ValueError as e:
                    print(f"\n=== Response Parsing Error ===")
                    print(f"Error: {str(e)}")
                    return {
                        'status': 'error',
                        'error_type': '响应解析错误',
                        'details': ['无法解析API响应']
                    }
            else:
                print(f"\n=== Error Response ===")
                print(f"Status Code: {response.status_code}")
                print(f"Error Content: {response.text}")
                return {
                    'status': 'error',
                    'error_type': 'API调用失败',
                    'details': [f'API返回错误: {response.status_code}', response.text]
                }

        # 处理GPA记录访问服务
        elif service_type == 'gpa_record_access':
            # 检查是否包含文件上传
            if 'student_list' in request.files:
                file = request.files['student_list']
                if not file or not file.filename:
                    return {
                        'status': 'error',
                        'error_type': '参数验证失败',
                        'details': ['请上传Excel文件']
                    }
                
                # 验证文件类型
                if not file.filename.endswith(('.xlsx', '.xls')):
                    return {
                        'status': 'error',
                        'error_type': '参数验证失败',
                        'details': ['请上传Excel文件(.xlsx或.xls格式)']
                    }
                
                # 读取Excel文件
                try:
                    df = pd.read_excel(file)
                    required_columns = ['id', 'name']  # 修改为API期望的列名
                    if not all(col in df.columns for col in required_columns):
                        return {
                            'status': 'error',
                            'error_type': '参数验证失败',
                            'details': [f'Excel文件必须包含以下列: {", ".join(required_columns)}']
                        }
                    
                    # 验证数据不为空
                    if df.empty:
                        return {
                            'status': 'error',
                            'error_type': '参数验证失败',
                            'details': ['Excel文件中没有数据']
                        }
                    
                    # 将DataFrame转换为列表
                    students = df[required_columns].to_dict('records')
                    
                    # 批量处理每个学生
                    results = []
                    for student in students:
                        # 发送单个请求
                        response = requests.post(url, json=student, headers=headers)
                        if response.status_code == 200:
                            results.append(response.json())
                        else:
                            print(f"Error processing student {student}: {response.text}")
                    
                    return {
                        'status': 'success',
                        'data': results
                    }
                    
                except Exception as e:
                    return {
                        'status': 'error',
                        'error_type': '文件处理失败',
                        'details': [str(e)]
                    }
            else:
                # 单个学生查询
                student_id = params.get('student_id')
                student_name = params.get('student_name')
                
                print(f"\n=== Request Parameters ===")
                print(f"Student ID: {student_id}")
                print(f"Student Name: {student_name}")
                print(f"All params: {params}")
                
                if not student_id or not student_name:
                    return {
                        'status': 'error',
                        'error_type': '参数验证失败',
                        'details': ['缺少必要参数: student_id 或 student_name']
                    }

                # 准备请求数据
                request_data = {
                    'id': student_id,
                    'name': student_name
                }
                print(f"\n=== Request Body ===")
                print(f"Request Data: {request_data}")

                # 发送POST请求
                print("\n=== Sending Request ===")
                response = requests.post(url, json=request_data, headers=headers)
                print(f"Response Status Code: {response.status_code}")
                print(f"Response Headers: {dict(response.headers)}")
                print(f"Response Content: {response.text}")
                
                # 处理响应
                if response.status_code == 200:
                    try:
                        result = response.json()
                        print(f"\n=== Response Data ===")
                        print(f"Parsed Response: {result}")
                        return {
                            'status': 'success',
                            'data': result
                        }
                    except ValueError as e:
                        print(f"\n=== Response Parsing Error ===")
                        print(f"Error: {str(e)}")
                        return {
                            'status': 'error',
                            'error_type': '响应解析错误',
                            'details': ['无法解析API响应']
                        }
                else:
                    print(f"\n=== Error Response ===")
                    print(f"Status Code: {response.status_code}")
                    print(f"Error Content: {response.text}")
                    return {
                        'status': 'error',
                        'error_type': 'API调用失败',
                        'details': [f'API返回错误: {response.status_code}', response.text]
                    }
        elif service_type == 'student_identity_authentication':
            # 检查是否包含文件上传
            if 'student_list' in request.files:
                file = request.files['student_list']
                if not file or not file.filename:
                    return {
                        'status': 'error',
                        'error_type': '参数验证失败',
                        'details': ['请上传Excel文件']
                    }
                
                # 验证文件类型
                if not file.filename.endswith(('.xlsx', '.xls')):
                    return {
                        'status': 'error',
                        'error_type': '参数验证失败',
                        'details': ['请上传Excel文件(.xlsx或.xls格式)']
                    }
                
                # 读取Excel文件
                try:
                    df = pd.read_excel(file)
                    required_columns = ['id', 'name', 'photo']
                    if not all(col in df.columns for col in required_columns):
                        return {
                            'status': 'error',
                            'error_type': '参数验证失败',
                            'details': [f'Excel文件必须包含以下列: {", ".join(required_columns)}']
                        }
                    
                    # 验证数据不为空
                    if df.empty:
                        return {
                            'status': 'error',
                            'error_type': '参数验证失败',
                            'details': ['Excel文件中没有数据']
                        }
                    
                    # 将DataFrame转换为列表
                    students = df[required_columns].to_dict('records')
                    
                    # 获取Excel文件所在目录
                    excel_dir = os.path.dirname(os.path.abspath(file.filename))
                    
                    # 批量处理每个学生
                    results = []
                    for student in students:
                        try:
                            # 构建照片文件的完整路径
                            photo_path = os.path.join(excel_dir, student['photo'])
                            
                            # 检查照片文件是否存在
                            if not os.path.exists(photo_path):
                                print(f"Photo file not found: {photo_path}")
                                results.append({
                                    'id': student['id'],
                                    'name': student['name'],
                                    'verified': False,
                                    'error': f"Photo file not found: {student['photo']}"
                                })
                                continue
                            
                            # 准备请求数据
                            request_data = {
                                'id': student['id'],
                                'name': student['name']
                            }
                            
                            # 准备文件
                            with open(photo_path, 'rb') as photo_file:
                                files = {
                                    'photo': (student['photo'], photo_file, 'image/jpeg')
                                }
                                
                                # 发送请求
                                response = requests.post(url, data=request_data, files=files, headers=headers)
                                if response.status_code == 200:
                                    result = response.json()
                                    results.append({
                                        'id': student['id'],
                                        'name': student['name'],
                                        'verified': result.get('status') == 'y'
                                    })
                                else:
                                    # 对于学生认证服务，500错误表示认证失败
                                    results.append({
                                        'id': student['id'],
                                        'name': student['name'],
                                        'verified': False
                                    })
                        except Exception as e:
                            print(f"Error processing student {student}: {str(e)}")
                            results.append({
                                'id': student['id'],
                                'name': student['name'],
                                'verified': False,
                                'error': str(e)
                            })
                    
                    return {
                        'status': 'success',
                        'data': results
                    }
                    
                except Exception as e:
                    return {
                        'status': 'error',
                        'error_type': '文件处理失败',
                        'details': [str(e)]
                    }
            else:
                # 单个学生查询
                student_id = params.get('student_id')
                student_name = params.get('student_name')
                photo = request.files.get('photo')
                
                print(f"\n=== Request Parameters ===")
                print(f"Student ID: {student_id}")
                print(f"Student Name: {student_name}")
                print(f"Photo: {photo.filename if photo else None}")
                print(f"All params: {params}")
                
                if not student_id or not student_name or not photo:
                    return {
                        'status': 'error',
                        'error_type': '参数验证失败',
                        'details': ['缺少必要参数: student_id, student_name 或 photo']
                    }

                # 准备请求数据
                request_data = {
                    'id': student_id,
                    'name': student_name
                }
                
                # 准备文件
                files = {
                    'photo': (photo.filename, photo, 'image/jpeg')
                }
                
                print(f"\n=== Request Body ===")
                print(f"Request Data: {request_data}")
                print(f"Files: {files}")

                # 发送POST请求
                print("\n=== Sending Request ===")
                response = requests.post(url, data=request_data, files=files, headers=headers)
                print(f"Response Status Code: {response.status_code}")
                print(f"Response Headers: {dict(response.headers)}")
                print(f"Response Content: {response.text}")
                
                # 处理响应
                if response.status_code == 200:
                    try:
                        result = response.json()
                        print(f"\n=== Response Data ===")
                        print(f"Parsed Response: {result}")
                        return {
                            'status': 'success',
                            'data': {
                                'id': student_id,
                                'name': student_name,
                                'verified': result.get('status') == 'y'
                            }
                        }
                    except ValueError as e:
                        print(f"\n=== Response Parsing Error ===")
                        print(f"Error: {str(e)}")
                        return {
                            'status': 'error',
                            'error_type': '响应解析错误',
                            'details': ['无法解析API响应']
                        }
                else:
                    # 对于学生认证服务，500错误表示认证失败
                    print(f"\n=== Authentication Failed ===")
                    print(f"Status Code: {response.status_code}")
                    print(f"Response Content: {response.text}")
                    return {
                        'status': 'success',
                        'data': {
                            'id': student_id,
                            'name': student_name,
                            'verified': False
                        }
                    }

        return {
            'status': 'error',
            'error_type': '未知服务类型',
            'details': [f'不支持的服务类型: {service_type}']
        }

    except Exception as e:
        print(f"\n=== Exception Details ===")
        print(f"Error Type: {type(e).__name__}")
        print(f"Error Message: {str(e)}")
        return {
            'status': 'error',
            'error_type': '服务器内部错误',
            'details': [str(e)]
        }


def approve_application(application_id, approver_role):
    """处理注册申请审批（带完整错误处理）"""
    try:
        application = RegistrationApplication.query.get(application_id)
        if not application:
            return {"success": False, "message": "申请记录不存在"}, 404

        original_status = application.status

        # 状态机验证
        if application.status == 'Pending Initial Review' and approver_role == 'E-Admin':
            application.status = 'Pending Final Review'
        elif application.status == 'Pending Final Review' and approver_role == 'Senior E-Admin':
            # 创建workspace
            workspace = Workspace(
                registration_application_id=application.application_id,
                organization_full_name=application.organization_full_name,
                organization_short_name=application.organization_short_name,
                created_at=datetime.utcnow()
            )
            db.session.add(workspace)
            db.session.flush()

            # 关联O-Convener
            o_convener = OConvener.query.filter_by(email=application.application_email).first()
            if o_convener:
                o_convener.workspace_id = workspace.id
            else:
                db.session.rollback()
                return {"success": False, "message": "对应的O-Convener账户不存在"}, 404

            application.workspace = workspace
            application.status = 'Approved'
        else:
            return {
                "success": False,
                "message": "无效的状态转换",
                "current_status": application.status,
                "required_role": "Senior E-Admin" if application.status == 'Pending Final Review' else 'E-Admin'
            }, 400

        db.session.commit()
        return {
            "success": True,
            "message": "审批流程完成",
            "new_status": application.status,
            "workspace_id": workspace.id if application.status == 'Approved' else None
        }

    except Exception as e:
        db.session.rollback()
        return {"success": False, "message": f"系统错误: {str(e)}"}, 500

