import os
from flask import Flask, request, render_template, jsonify, redirect, json, send_from_directory, abort
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
import requests
import datetime
from flask import session
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
import pymysql


from models.user import users,EAdmin,TAdmin,OConvener,DataUser,db
from models.workspace import APIConfig, BankAccount, Policy, Workspace, Service
from services import get_api_config, call_external_api

## create a Flask instance
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost:3306/e-dba'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
migrate = Migrate(app, db)

app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'uploads')
app.secret_key = os.urandom(24)  # 生成随机密钥

login_manager = LoginManager()
login_manager.init_app(app)
@login_manager.user_loader
def load_user(user_id):
    return users.query.get(int(user_id))


from routes.oconvener_bp import oconvener_bp
from routes.auth import auth_bp
from routes.datauser_bp import datauser_bp
from routes.course_bp import course_bp
from routes.admin_bp import admin_bp
app.register_blueprint(oconvener_bp)
app.register_blueprint(auth_bp)
app.register_blueprint(datauser_bp)
app.register_blueprint(course_bp)
app.register_blueprint(admin_bp)

from flask_cors import CORS
CORS(app, resources={r"/api/*": {"origins": "*"}})

@app.route('/', methods=['GET'])
def show_login_form():
    return render_template('login.html')


@app.route('/api/login', methods=['POST'])
def login():
    # 获取表单数据
    email = request.form.get('email')
    password = request.form.get('password')
    print(email, password)

    # 参数校验
    if not email or not password:
        return jsonify({"success": False, "message": "Email and password are required"}), 400

    # 查询用户
    user = users.query.filter_by(email=email).first()
    if not user:
        return jsonify({"success": False, "message": "User not found"}), 404

    # 密码验证
    if user.password != password:  # 注意：此处存在安全隐患！
        return jsonify({"success": False, "message": "Invalid password"}), 401

    login_user(user)
    # 角色处理逻辑
    role_mapping = {
        'O-Convener': OConvener,
        'E-Admin': EAdmin,
        'T-Admin': TAdmin,
        'DataUser': DataUser,
        'User': users
    }

    try:
        # 获取角色模型
        role_model = role_mapping.get(user.role)
        print(role_model)

        if role_model:
            # 检查并创建角色记录
            role_record = role_model.query.filter_by(id=user.id).first()
            if not role_record:
                new_role = role_model(id=user.id)
                db.session.add(new_role)
                db.session.commit()


        return jsonify({
            "success": True,
            "role": user.role,
            "id": user.id
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": f"Database error: {str(e)}"}), 500


@app.route('/user.html')
def user_dashboard():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")

    user = users.query.get(int(user_id))
    if not user:
        abort(404, "User not found")

    return render_template('user.html', current_user=user)  # 传递用户对象到模板

@app.route('/oconvener.html')
def oconvener_dashboard():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")

    user = users.query.get(int(user_id))
    if not user:
        abort(404, "User not found")

    return render_template('oconvener.html', current_user=user)  # 传递用户对象到模板

@app.route('/E-Admin/E-admin_operate_page.html')
def E_Admin_dashboard():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")

    user = users.query.get(int(user_id))
    if not user:
        abort(404, "User not found")

    return render_template('/E-Admin/E-admin_operate_page.html', current_user=user)  # 传递用户对象到模板


@app.route('/logout')
def logout():
    # 原session操作已删除
    return redirect('/login.html')


@app.route('/<page_name>.html')
def serve_page(page_name):
    return send_from_directory('templates', f'{page_name}.html')


@app.route("/t-Admin/<page_name>")
def tadmin_pages(page_name):
    return render_template(f"t-Admin/{page_name}")

@app.route('/E_Admin/<page_name>')
def eadmin_pages(page_name):
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")
    
    if page_name == 'Data_sharing_Policy_Management_Page.html':
        policies = Policy.query.all()
        return render_template(f"E_Admin/{page_name}", user_id=user_id, policies=policies)
    elif page_name == 'Policy_Edit_Page.html':
        policy_id = request.args.get('policy_id')
        if not policy_id:
            abort(400, "Missing policy ID")
        policy = Policy.query.get_or_404(policy_id)
        return render_template(f"E_Admin/{page_name}", user_id=user_id, policy=policy)
    elif page_name == 'Policy_Addition_Page.html':
        return render_template(f"E_Admin/{page_name}", user_id=user_id)
    elif page_name == 'E-admin_operate_page.html':
        return render_template(f"E_Admin/{page_name}", user_id=user_id)
    
    return render_template(f"E_Admin/{page_name}", user_id=user_id)

@app.route("/E_Admin/organization_choose")
def organization_choose():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")
    
    # 获取所有workspace数据
    workspaces = Workspace.query.all()
    return render_template("E_Admin/Organization_Choose_page.html", 
                         user_id=user_id,
                         workspaces=workspaces)

@app.route("/E_Admin/application_list")
def application_list():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")
    return render_template("E_Admin/application_list_page.html", user_id=user_id)

@app.route("/E_Admin/settings_page")
def settings_page():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")
    return render_template("E_Admin/settings_page.html", user_id=user_id)

@app.route("/dataUser_dashBorad/<page_name>")
def dataUser_dashBorad(page_name):
    return render_template(f"dataUser_dashBorad/{page_name}")

@app.route("/workspace/<page_name>")
def workspace_pages(page_name):
    return render_template(f"workspace/{page_name}")



@app.route('/config_form', methods=['GET'])
def show_config_form():
    return render_template('config_form.html')

# 🛠️ 提交接口配置
# 配置提交路由
@app.route('/api/config_form', methods=['POST'])
def handle_config():
    try:
        # 解析请求数据
        data = request.get_json()

        # 数据校验
        required_fields = ['service_type','base_url', 'path', 'method', 'input', 'output']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({"error": f"字段 '{field}' 不能为空"}), 400

        # 解析JSON字段
        input_data = json.loads(data['input'])
        output_data = json.loads(data['output'])

        # 写入数据库
        new_config = APIConfig(
            workspace_id=1,  # 这里假设机构ID固定为1
            service_type=data['service_type'],
            base_url=data['base_url'],
            path=data['path'],
            method=data['method'],
            input=input_data,
            output=output_data
        )
        db.session.add(new_config)
        db.session.commit()

        return jsonify({"message": "配置保存成功"}), 200

    except json.JSONDecodeError as e:
        return jsonify({"error": "JSON解析失败", "details": str(e)}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "服务器错误", "details": str(e)}), 500


# 动态接口调用页面
@app.route('/api/get-config')  # 定义路由端点
def get_config():
    # 从请求的 URL 查询参数中获取值
    service_type = request.args.get('service_type')  # 获取 service_type 参数
    workspace_id = request.args.get('workspace_id')  # 获取 workspace_id 参数

    # 数据库查询：根据两个参数查找匹配记录
    config = APIConfig.query.filter_by(
        service_type=service_type,
        workspace_id=workspace_id
    ).first()  # 获取第一条匹配记录

    if not config:
        return jsonify({"error": "配置不存在"}), 404  # 找不到配置返回404错误

    # 返回找到的配置的JSON格式数据
    return jsonify({
        "service_type": config.service_type,
        "workspace_id": config.workspace_id,
        "inputs": config.input,
        "method": config.method,
        "base_url": config.base_url,
        "path": config.path
    })

@app.route('/dynamic-form')
def show_dynamic_form():
    return send_from_directory('templates', 'dynamic_form.html')

def has_permission(user, service_type, workspace_id):
    """检查用户是否有权限访问特定服务"""
    # 如果是DataUser，直接允许访问
    if isinstance(user, DataUser):
        return True
    
    # 检查用户角色
    if user.role == 'Admin':
        return True
    
    # 检查用户是否是工作空间的成员
    if user.role in ['O-Convener', 'DataUser']:
        # 对于O-Convener，检查是否是该工作空间的管理者
        if user.role == 'O-Convener':
            oconvener = OConvener.query.filter_by(user_id=user.id, workspace_id=workspace_id).first()
            return oconvener is not None
        
        # 对于DataUser，检查是否有权限访问该服务
        # TODO: 实现DataUser的权限检查逻辑
        return True
    
    return False

def log_api_call(user_id, service_type, workspace_id, success):
    """记录API调用"""
    try:
        # TODO: 实现API调用日志记录
        pass
    except Exception as e:
        print(f"记录API调用失败: {str(e)}")

@app.route('/api/call-external', methods=['GET', 'POST'])
def call_external():
    """处理外部API调用请求"""
    try:
        # 获取请求参数
        service_type = request.args.get('service_type') or request.form.get('service_type')
        workspace_id = request.args.get('workspace_id') or request.form.get('workspace_id')
        user_id = request.args.get('user_id') or request.form.get('user_id')
        service_fee = float(request.form.get('service_fee', 0))
        
        # 添加调试日志
        print("Received request parameters:")
        print(f"service_type: {service_type}")
        print(f"workspace_id: {workspace_id}")
        print(f"user_id: {user_id}")
        print(f"service_fee: {service_fee}")
        print(f"form data: {request.form}")
        
        if not all([service_type, workspace_id, user_id]):
            return jsonify({
                'status': 'error',
                'error_type': '参数错误',
                'details': [f'缺少必要参数: service_type={service_type}, workspace_id={workspace_id}, user_id={user_id}']
            }), 400

        # 获取用户信息
        user = DataUser.query.get(user_id)
        if not user:
            return jsonify({
                'status': 'error',
                'error_type': '用户错误',
                'details': ['用户不存在']
            }), 404

        # 检查用户是否有权限访问该服务
        if not has_permission(user, service_type, workspace_id):
            return jsonify({
                'status': 'error',
                'error_type': '权限错误',
                'details': ['您没有权限访问此服务']
            }), 403

        # 检查余额
        if user.balance < service_fee:
            return jsonify({
                'status': 'error',
                'error_type': '余额不足',
                'details': [f'当前余额: ${user.balance:.2f}, 所需费用: ${service_fee:.2f}']
            }), 400

        # 扣除费用
        user.balance -= service_fee
        db.session.commit()

        # 调用外部API
        result = call_external_api(service_type, workspace_id, request.form)
        
        # 记录API调用
        log_api_call(user_id, service_type, workspace_id, result.get('status') == 'success')
        
        return jsonify(result)

    except Exception as e:
        db.session.rollback()
        print(f"API调用错误: {str(e)}")
        return jsonify({
            'status': 'error',
            'error_type': '服务器内部错误',
            'details': [str(e)]
        }), 500

@app.route('/api/save_bank_account', methods=['POST'])
@login_required
def save_bank_account():
    print("\n==== 收到新请求 ====")
    print("请求头:", dict(request.headers))
    print("原始请求数据:", request.get_data(as_text=True))  # 获取原


    try:
        data = request.get_json()
        required_fields = ['workspace_id', 'bank', 'account_number', 'account_name', 'password']
        missing = [field for field in required_fields if field not in data]
        if missing:
            print(f"缺少字段: {missing}")  # 明确提示具体缺失字段
            return jsonify({"error": f"缺少字段: {', '.join(missing)}"}), 400

        # 检查是否已存在
        existing = BankAccount.query.filter_by(
            workspace_id=data['workspace_id'],
            account_number=data['account_number']
        ).first()
        if existing:
            return jsonify({"success": False, "error": "银行账户已存在"}), 400

        # 创建新记录
        new_account = BankAccount(
            workspace_id=data['workspace_id'],
            bank=data['bank'],
            account_number=data['account_number'],
            account_name=data['account_name'],
            password=data['password']
        )
        db.session.add(new_account)
        db.session.commit()
        return jsonify({"success": True}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/policies', methods=['POST'])
def create_policy():
    try:
        data = request.get_json()
        new_policy = Policy(
            title=data['title'],
            type=data['type'],
            content=data['content'],
            summary=data['summary']
        )
        db.session.add(new_policy)
        db.session.commit()
        return jsonify({"success": True, "message": "Policy created successfully"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/policies/<int:policy_id>', methods=['PUT'])
def update_policy(policy_id):
    try:
        policy = Policy.query.get_or_404(policy_id)
        data = request.get_json()
        
        policy.title = data['title']
        policy.type = data['type']
        policy.content = data['content']
        policy.summary = data['summary']
        
        db.session.commit()
        return jsonify({"success": True, "message": "Policy updated successfully"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/policies/<int:policy_id>', methods=['DELETE'])
def delete_policy(policy_id):
    try:
        policy = Policy.query.get_or_404(policy_id)
        db.session.delete(policy)
        db.session.commit()
        return jsonify({"success": True, "message": "Policy deleted successfully"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": str(e)}), 500

# 添加直接访问E-Admin页面的路由
@app.route('/E_Admin/Data_sharing_Policy_Management_Page.html')
def data_sharing_policy_management():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")
    policies = Policy.query.all()
    return render_template("E_Admin/Data_sharing_Policy_Management_Page.html", user_id=user_id, policies=policies)

@app.route('/E_Admin/Policy_Edit_Page.html')
def policy_edit():
    user_id = request.args.get('id')
    policy_id = request.args.get('policy_id')
    if not user_id or not policy_id:
        abort(400, "Missing user ID or policy ID")
    policy = Policy.query.get_or_404(policy_id)
    return render_template("E_Admin/Policy_Edit_Page.html", user_id=user_id, policy=policy)

@app.route('/E_Admin/Policy_Addition_Page.html')
def policy_addition():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")
    return render_template("E_Admin/Policy_Addition_Page.html", user_id=user_id)

@app.route('/E_Admin/E-admin_operate_page.html')
def e_admin_operate():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")
    return render_template("E_Admin/E-admin_operate_page.html", user_id=user_id)

@app.route('/api/get_user_info')
def get_user_info():
    """获取用户余额和服务费用信息"""
    try:
        user_id = request.args.get('user_id')
        workspace_id = request.args.get('workspace_id')
        service_type = request.args.get('service_type')

        if not all([user_id, workspace_id, service_type]):
            return jsonify({
                'success': False,
                'message': 'Missing required parameters'
            }), 400

        # 获取用户信息
        user = DataUser.query.get(user_id)
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404

        # 获取服务费用
        service = Service.query.filter_by(
            workspace_id=workspace_id,
            service_type=service_type
        ).first()

        if not service:
            return jsonify({
                'success': False,
                'message': 'Service not found'
            }), 404

        return jsonify({
            'success': True,
            'balance': user.balance,
            'service_fee': service.fee
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("✅ 数据库连接成功，表已创建")
    app.run(debug=True,port=5000)
