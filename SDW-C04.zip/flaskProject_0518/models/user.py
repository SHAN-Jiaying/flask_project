from datetime import datetime
from flask_login import UserMixin
from sqlalchemy.orm import validates, foreign, remote
# extensions.py
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()

class users(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    user_name = db.Column(db.String(80),nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.Enum('O-Convener', 'E-Admin', 'SE-Admin', 'T-Admin', 'DataUser', 'User'), nullable=False)
    is_logged_in = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    verification_code = db.Column(db.String(6), default='')
    questions = db.relationship('Question', backref='user', lazy='dynamic')


#再插入oconvener记录前先有workspace
class OConvener(db.Model):
    __tablename__ = 'oconveners'
    id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    registration_application_id = db.Column(
        db.Integer,  # 修改类型为Integer
        db.ForeignKey('registration_applications.application_id'),  # 添加外键约束
        unique=True  # 按需决定是否保持唯一性
    )
    workspace_id = db.Column(
        db.Integer,
        db.ForeignKey('workspaces.id'),
        unique=True  # 确保一个O-Convener对应一个workspace
    )
    member_list_file = db.Column(db.String(255))
    # 添加与RegistrationApplication的关系
    registration_application = db.relationship(
        "RegistrationApplication",
        backref="oconveners",
        foreign_keys=[registration_application_id]
    )
    user = db.relationship("users", backref="oconveners")


class EAdmin(db.Model):
    __tablename__ = 'e_admin'
    id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    admin_level = db.Column(db.String(50))
    last_login = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("users", backref="e_admins")


class TAdmin(db.Model):
    __tablename__ = 't_admins'
    id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    managed_admins = db.Column(db.JSON)
    last_login = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("users", backref="t_admins")


class DataUser(db.Model):
    __tablename__ = 'data_users'
    id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey('workspaces.id'), nullable=False)
    access_rights = db.Column(db.JSON)
    last_access = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("users", backref="data_users")
    payment_quota = db.Column(db.Float, default=500.00, comment='The payment limit of member for paper downloads')
    balance = db.Column(db.Float, default=0.00, comment='用户账户余额')

    @validates('access_rights')
    def validate_access_rights(self, key, value):
        if value not in [1, 2, 3]:
            raise ValueError("Invalid access rights")
        return value


class RegistrationApplication(db.Model):
    __tablename__ = 'registration_applications'
    application_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    application_email = db.Column(db.String(120), nullable=False)
    organization_full_name = db.Column(db.String(255), nullable=False)
    organization_short_name = db.Column(db.String(80), nullable=False)
    proof_document = db.Column(db.String(255))
    status = db.Column(db.Enum('Pending Initial Review', 'Pending Final Review', 'Approved', 'Rejected'),
                       nullable=False, default='Pending Initial Review')
    rejection_reason = db.Column(db.String(255))
    submission_time = db.Column(db.TIMESTAMP, nullable=False)
    last_processed_time = db.Column(db.TIMESTAMP, nullable=True)
    workspace = db.relationship(
        "Workspace",
        backref="registration_application",
        uselist=False
    )
    # 更新与users表的关系定义
    user = db.relationship(
        "users",
        primaryjoin="foreign(RegistrationApplication.application_email) == remote(users.email)",
        backref=db.backref("registration_applications", lazy="dynamic"),
        uselist=False
    )