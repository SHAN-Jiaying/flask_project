from models.user import db
from datetime import datetime

class APIConfig(db.Model):
    __tablename__ = 'api_config'
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, default=1)
    service_type = db.Column(db.String(50), nullable=False)  # 必须字段
    base_url = db.Column(db.String(255), nullable=False)
    path = db.Column(db.String(255), nullable=False)
    method = db.Column(db.String(10), nullable=False)
    input = db.Column(db.JSON, nullable=True)
    output = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, server_default=db.func.now())


class Workspace(db.Model):
    """组织工作空间核心表"""
    __tablename__ = 'workspaces'

    id = db.Column(db.Integer, primary_key=True)
    # 从注册申请表继承的机构信息
    registration_application_id = db.Column(
        db.Integer,
        db.ForeignKey('registration_applications.application_id'),
        unique=True  # 确保一个注册申请对应一个workspace
    )
    organization_full_name = db.Column(db.String(255), nullable=False)
    organization_short_name = db.Column(db.String(80), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 与O-Convener的一对一关系（通过反向引用实现）
    o_convener = db.relationship(
        "OConvener",
        backref="workspace",
        uselist=False  # 一对一关系
    )
    services = db.relationship(
        'Service',
        back_populates='workspace',
        foreign_keys='Service.workspace_id'  # 明确指定外键
    )

class MembershipPricing(db.Model):
    __tablename__ = 'membership_pricing'
    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey('workspaces.id'), nullable=False)
    access_right = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)


class BankAccount(db.Model):
    """工作空间银行账户表"""
    __tablename__ = 'bank_accounts'

    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(
        db.Integer,
        db.ForeignKey('workspaces.id'),
        nullable=False
    )
    bank = db.Column(db.String(255), nullable=False)
    account_number = db.Column(db.String(255), nullable=False)
    account_name = db.Column(db.String(255), nullable=False)
    balance = db.Column(db.Float, default=0.0)
    password = db.Column(db.String(255))  # 确保字段名为password_hash


class MemberPolicy(db.Model):
    """成员访问策略表（支持通配符配置）"""
    __tablename__ = 'member_policies'

    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(
        db.Integer,
        db.ForeignKey('workspaces.id'),
        nullable=False
    )
    email_pattern = db.Column(db.String(255), nullable=False)  # 例如 *@uic.edu.cn
    access_level = db.Column(
        db.Integer,
        nullable=False,
        comment='1-Public, 2-Private Consumer, 3-Private Provider'
    )
    thesis_quota = db.Column(
        db.Float,
        default=0.0,
        comment='论文下载配额（金额）'
    )


class Service(db.Model):
    """服务配置表（修改原service类）"""
    __tablename__ = 'services'

    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(
        db.Integer,
        db.ForeignKey('workspaces.id'),
        nullable=False
    )
    service_type = db.Column(
        db.String(50),
        nullable=False,
    )
    fee = db.Column(db.Float, default=0.0)

    access_scope = db.Column(
        db.String(20),
        default='individual',
        comment='all/individual 指定可访问机构范围'
    )
    is_active = db.Column(db.Boolean, default=True)
    workspace = db.relationship('Workspace', back_populates='services')

    # 添加序列化方法
    def to_dict(self):
        return {
            'id': self.id,
            'service_type': self.service_type,
            'fee': float(self.fee),
            'access_scope': self.access_scope,
            'workspace_id': self.workspace_id
        }



class ActivityLog(db.Model):
    """工作空间活动日志表"""
    __tablename__ = 'activity_logs'

    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(
        db.Integer,
        db.ForeignKey('workspaces.id'),
        nullable=False
    )
    user_id = db.Column(
        db.Integer,
        db.ForeignKey('users.id'),
        nullable=False
    )
    activity_type = db.Column(
        db.String(50),
        nullable=False,
        comment='例如：service_access, member_edit'
    )
    details = db.Column(db.JSON)  # 存储结构化日志信息
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


# 数据库模型
class Course(db.Model):
    __tablename__ = 'courses'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    units = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'units': self.units,
            'description': self.description
        }


class Question(db.Model):
    __tablename__ = 'questions'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    date = db.Column(db.DateTime, nullable=False)
    state = db.Column(db.String(20), default='unanswered', nullable=False)  # answered/unanswered
    answer = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'date': self.date.strftime('%Y-%m-%d'),
            'state': self.state,
            'answer': self.answer,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }

class PaymentRecord(db.Model):
    __tablename__ = 'payment_records'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(50), nullable=False)
    detail=db.Column(db.String(200), nullable=False)
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("users", backref="payment_records")

class Policy(db.Model):
    """Policy model for storing system policies"""
    __tablename__ = 'policies'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # copyright, data-privacy, user-behavior, data-sharing
    content = db.Column(db.Text, nullable=False)
    summary = db.Column(db.String(500), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'type': self.type,
            'content': self.content,
            'summary': self.summary,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None,
            'is_active': self.is_active
        }

class SystemBankAccount(db.Model):
    """E-DBA系统银行账户表"""
    __tablename__ = 'system_bank_accounts'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    account = db.Column(db.String(50), unique=True, nullable=False)
    bank = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<SystemBankAccount {self.name}>'

class UserNotification(db.Model):
    """用户通知表"""
    __tablename__ = 'user_notifications'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    subject = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关联用户
    user = db.relationship('users', backref=db.backref('notifications', lazy=True))

    def __repr__(self):
        return f'<UserNotification {self.subject}>'

    def to_dict(self):
        return {
            'id': self.id,
            'subject': self.subject,
            'message': self.message,
            'is_read': self.is_read,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }