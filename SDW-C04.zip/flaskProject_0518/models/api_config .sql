-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2025-05-20 05:49:15
-- 服务器版本： 10.4.32-MariaDB
-- PHP 版本： 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `e-dba`
--

-- --------------------------------------------------------

--
-- 表的结构 `api_config`
--

CREATE TABLE `api_config` (
  `id` int(11) NOT NULL,
  `workspace_id` varchar(255) DEFAULT NULL,
  `service_type` varchar(50) NOT NULL,
  `base_url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `method` varchar(10) NOT NULL,
  `input` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`input`)),
  `output` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`output`)),
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `api_config`
--

INSERT INTO `api_config` (`id`, `workspace_id`, `service_type`, `base_url`, `path`, `method`, `input`, `output`, `created_at`) VALUES
(9, '1', 'bank_account_auth', 'http://172.16.160.88:8001', '/hw/bank/authenticate', 'POST', '{\"bank\": \"string\", \"account_name\": \"string\", \"account_number\": \"string\", \"password\": \"string\"}', '{\"status\": \"string\"}', '2025-05-11 23:24:30'),
(10, '1', 'bank_transfer', 'http://172.16.160.88:8001', '/hw/bank/transfer', 'POST', '{\"from_bank\": \"string\", \"from_name\": \"string\", \"from_account\": \"string\", \"password\": \"string\", \"to_bank\": \"string\", \"to_name\": \"string\", \"to_account\": \"string\", \"amount\": \"int\"}', '{\"status\": \"string\", \"reason\": \"string\"}', '2025-05-11 23:28:46'),
(16, '1', 'thesis_download', 'http://172.16.160.88:8001', '/hw/thesis/pdf', 'GET', '{\"title\": \"string\"}', '{\"file\": \"string\", \"error\": \"string\"}', '2025-05-17 12:46:07'),
(17, '1', 'gpa_record_access', 'http://172.16.160.88:8001', '/hw/student/record', 'POST', '{\"name\": \"string\", \"id\": \"string\"}', '{\"name\": \"string\", \"enroll_year\": \"string\", \"graduation_year\": \"string\", \"gpa\": \"float\"}', '2025-05-17 18:15:17'),
(18, '1', 'thesis_search', 'http://172.16.160.88:8001', '/hw/thesis/search', 'POST', '{\"keywords\": \"string\"}', '{\"title\": \"string\", \"abstract\": \"string\"}', '2025-05-18 12:04:48'),
(20, '1', 'student_identity_authentication', 'http://172.16.160.88:8001', 'hw/student/authenticate', 'POST', '{\"name\": \"string\", \"id\": \"string\", \"photo\": \"file\"}', '{\"status\": \"string\"}', '2025-05-18 12:31:59');

--
-- 转储表的索引
--

--
-- 表的索引 `api_config`
--
ALTER TABLE `api_config`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `api_config`
--
ALTER TABLE `api_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
