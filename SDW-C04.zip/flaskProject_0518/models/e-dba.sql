-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2025-05-16 11:23:03
-- 服务器版本： 10.4.32-MariaDB
-- PHP 版本： 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `e-dba`
--

-- --------------------------------------------------------

--
-- 表的结构 `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `workspace_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `activity_type` varchar(50) NOT NULL COMMENT '例如：service_access, member_edit',
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `timestamp` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `workspace_id`, `user_id`, `activity_type`, `details`, `timestamp`) VALUES
(25, 1, 21, 'service_access', '{\"service\": \"student_identity_authentication\"}', '2025-05-16 08:57:07'),
(26, 1, 21, 'service_access', '{\"service\": \"gpa_record_access\"}', '2025-05-16 08:57:25'),
(27, 1, 21, 'service_access', '{\"service\": \"student_identity_authentication\"}', '2025-05-16 08:57:29');

-- --------------------------------------------------------

--
-- 表的结构 `api_config`
--

CREATE TABLE `api_config` (
  `id` int(11) NOT NULL,
  `workspace_id` varchar(255) DEFAULT NULL,
  `service_type` varchar(50) NOT NULL,
  `base_url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `method` varchar(10) NOT NULL,
  `input` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`input`)),
  `output` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`output`)),
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `api_config`
--

INSERT INTO `api_config` (`id`, `workspace_id`, `service_type`, `base_url`, `path`, `method`, `input`, `output`, `created_at`) VALUES
(3, '1', 'gpa_record_access', 'http://172.16.160.88:8001', '/hw/student/record', 'POST', '{\"name\": \"string\", \"id\": \"string\"}', '{\"name\": \"string\", \"enroll_year\": \"string\", \"graduation_year\": \"string\", \"gpa\": \"float\"}', '2025-04-27 00:19:50'),
(4, '1', 'thesis_search', 'http://172.16.160.88:8001', '/hw/thesis/search', 'POST', '{\"keywords\": \"string\"}', '{\"title\": \"string\", \"abstract\": \"string\"}', '2025-04-27 15:12:49'),
(5, '1', 'student_identity_authentication', 'http://172.16.160.88:8001', '/hw/student/authenticate', 'POST', '{\"name\":\"string\",\"id\":\"string\",\"photo\":\"file\"}', '{\"status\": \"string\"}', '2025-04-27 15:18:50'),
(7, '1', 'thesis_download', 'http://172.16.160.88:8001', '/hw/thesis/pdf', 'GET', '{\"title\": \"string\"}', '{\"file\": \"string\", \"error\": \"string\"}', '2025-04-29 14:27:41'),
(9, '1', 'bank_account_auth', 'http://172.16.160.88:8001', '/hw/bank/authenticate', 'POST', '{\"bank\": \"string\", \"account_name\": \"string\", \"account_number\": \"string\", \"password\": \"string\"}', '{\"status\": \"string\"}', '2025-05-11 23:24:30'),
(10, '1', 'bank_transfer', 'http://172.16.160.88:8001', '/hw/bank/transfer', 'POST', '{\"from_bank\": \"string\", \"from_name\": \"string\", \"from_account\": \"string\", \"password\": \"string\", \"to_bank\": \"string\", \"to_name\": \"string\", \"to_account\": \"string\", \"amount\": \"int\"}', '{\"status\": \"string\", \"reason\": \"string\"}', '2025-05-11 23:28:46');

-- --------------------------------------------------------

--
-- 表的结构 `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `workspace_id` int(11) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00 COMMENT '账户余额'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `bank_accounts`
--

INSERT INTO `bank_accounts` (`id`, `workspace_id`, `bank`, `account_number`, `account_name`, `password`, `balance`) VALUES
(2, 1, 'FutureLearn Federal Bank', '670547811218584', 'Utopia Credit Union', '9978', 0.00);

-- --------------------------------------------------------

--
-- 表的结构 `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `units` int(11) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `courses`
--

INSERT INTO `courses` (`id`, `title`, `units`, `description`) VALUES
(5, 'Database Systems', 3, 'Teaches the basic concepts of database systems, relational models, SQL language, database design, query optimization, transaction management, and database security, with hands-on experience using MySQL or PostgreSQL.'),
(6, 'Software Engineering', 3, 'Systematically expounds the entire process of software development, including methods and techniques for requirements analysis, design, coding, testing, and maintenance, emphasizing the importance of teamwork and project management.'),
(7, 'Computer Organization and Architecture', 3, 'Explains the basic composition and working principles of computer hardware, including the design and implementation of CPU, memory, and I/O systems, as well as assembly language programming and instruction sets.'),
(8, 'Mobile Application Development', 3, 'Teaches the fundamental principles and technologies of mobile application development for Android or iOS platforms, covering UI design, network communication, data storage, and other aspects.'),
(9, 'Cloud Computing and Big Data', 3, 'Introduces the basic concepts, technical architectures, and application scenarios of cloud computing and big data, including big data processing frameworks such as Hadoop and Spark, and cloud service platforms such as AWS and Alibaba Cloud.'),
(10, 'Information Security', 3, 'Teaches the basic concepts, theories, and technologies of information security, including cryptography, network security, system security, application security, and methods for security vulnerability analysis and prevention.'),
(11, 'financial computing', 3, 'a financial course');

-- --------------------------------------------------------

--
-- 表的结构 `data_users`
--

CREATE TABLE `data_users` (
  `id` int(11) NOT NULL,
  `workspace_id` int(20) NOT NULL,
  `access_rights` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`access_rights`)),
  `last_access` datetime DEFAULT NULL,
  `payment_quota` decimal(10,2) DEFAULT NULL COMMENT 'Payment limit for users to download papers',
  `balance` float(10,2) DEFAULT 0.00 COMMENT '用户账户余额'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `data_users`
--

INSERT INTO `data_users` (`id`, `workspace_id`, `access_rights`, `last_access`, `payment_quota`, `balance`) VALUES
(21, 1, '3', '2025-05-13 14:30:26', 500.00, 390.00),
(74, 1, '1', '2025-05-15 15:46:52', 300.00, 0.00),
(75, 1, '2', '2025-05-15 15:49:09', 200.00, 0.00),
(82, 1, '3', '2025-05-16 08:46:56', 500.00, 0.00),
(83, 1, '2', '2025-05-16 08:46:56', 300.00, 0.00),
(84, 1, '1', '2025-05-16 08:46:56', 100.00, 0.00);

-- --------------------------------------------------------

--
-- 表的结构 `e_admin`
--

CREATE TABLE `e_admin` (
  `id` int(11) NOT NULL,
  `admin_level` varchar(50) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `e_admin`
--

INSERT INTO `e_admin` (`id`, `admin_level`, `last_login`) VALUES
(3, NULL, '2025-05-04 12:44:06');

-- --------------------------------------------------------

--
-- 表的结构 `membership_pricing`
--

CREATE TABLE `membership_pricing` (
  `id` int(11) NOT NULL,
  `workspace_id` int(11) NOT NULL,
  `access_right` int(11) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `membership_pricing`
--

INSERT INTO `membership_pricing` (`id`, `workspace_id`, `access_right`, `price`) VALUES
(1, 1, 1, 15),
(2, 1, 2, 50),
(3, 1, 3, 100);

-- --------------------------------------------------------

--
-- 表的结构 `member_policies`
--

CREATE TABLE `member_policies` (
  `id` int(11) NOT NULL,
  `workspace_id` int(11) NOT NULL,
  `email_pattern` varchar(255) NOT NULL,
  `access_level` int(11) NOT NULL COMMENT '1-Public, 2-Private Consumer, 3-Private Provider',
  `thesis_quota` float DEFAULT NULL COMMENT '论文下载配额（金额）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `oconveners`
--

CREATE TABLE `oconveners` (
  `id` int(11) NOT NULL,
  `registration_application_id` int(11) DEFAULT NULL,
  `workspace_id` int(11) DEFAULT NULL,
  `member_list_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `oconveners`
--

INSERT INTO `oconveners` (`id`, `registration_application_id`, `workspace_id`, `member_list_file`) VALUES
(2, 11, 1, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `payment_records`
--

CREATE TABLE `payment_records` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` float NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `detail` varchar(200) NOT NULL,
  `payment_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `payment_records`
--

INSERT INTO `payment_records` (`id`, `user_id`, `amount`, `payment_method`, `detail`, `payment_date`) VALUES
(1, 2, 165, 'external_bank_api', 'member added fee', '2025-05-16 08:46:56'),
(2, 21, 10, 'Transfer', 'student_identity_authentication', '2025-05-16 08:57:07'),
(3, 21, 20, 'Transfer', 'gpa_record_access', '2025-05-16 08:57:25'),
(4, 21, 10, 'Transfer', 'student_identity_authentication', '2025-05-16 08:57:29');

-- --------------------------------------------------------

--
-- 表的结构 `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `date` datetime NOT NULL,
  `state` enum('unanswered','answered') NOT NULL,
  `answer` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `questions`
--

INSERT INTO `questions` (`id`, `user_id`, `title`, `description`, `date`, `state`, `answer`, `created_at`) VALUES
(1, 21, '无法使用', '为什么无法使用', '2025-05-23 00:00:00', 'answered', NULL, '2025-05-14 06:21:00'),
(2, 21, '无法使用2', '为什么无法使用2', '2025-05-25 00:00:00', 'answered', NULL, '2025-05-14 06:23:53'),
(3, 21, '为什么', '为什么1111', '2025-05-24 00:00:00', 'answered', NULL, '2025-05-15 17:37:23');

-- --------------------------------------------------------

--
-- 表的结构 `registration_applications`
--

CREATE TABLE `registration_applications` (
  `application_id` int(11) NOT NULL,
  `application_email` varchar(120) NOT NULL,
  `organization_full_name` varchar(255) NOT NULL,
  `organization_short_name` varchar(80) NOT NULL,
  `proof_document` varchar(255) DEFAULT NULL,
  `status` enum('Pending Initial Review','Pending Final Review','Approved','Rejected') NOT NULL,
  `rejection_reason` varchar(255) DEFAULT NULL,
  `submission_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_processed_time` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `registration_applications`
--

INSERT INTO `registration_applications` (`application_id`, `application_email`, `organization_full_name`, `organization_short_name`, `proof_document`, `status`, `rejection_reason`, `submission_time`, `last_processed_time`) VALUES
(11, 'ljt@qq.com', 'happyplace', 'hp', 'F:\\UIC\\year3_2\\SDW\\testCase\\flaskProject\\uploads\\ljt_qq.com.pdf', 'Approved', NULL, '2025-05-05 05:42:23', NULL),
(13, 'heleb@qq.com', 'gooodplace', 'gp', 'F:\\UIC\\year3_2\\SDW\\testCase\\flaskProject\\uploads\\heleb_qq.com.pdf', 'Pending Initial Review', NULL, '2025-05-12 03:17:54', NULL),
(14, 'okk@qq.com', 'sbbbbb', 'sb', 'F:\\UIC\\year3_2\\SDW\\testCase\\flaskProject\\uploads\\okk_qq.com.pdf', 'Pending Initial Review', NULL, '2025-05-13 14:17:46', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `workspace_id` int(11) NOT NULL,
  `service_type` varchar(50) NOT NULL,
  `fee` float DEFAULT NULL,
  `access_scope` varchar(20) DEFAULT NULL COMMENT 'all/individual 指定可访问机构范围',
  `is_active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `services`
--

INSERT INTO `services` (`id`, `workspace_id`, `service_type`, `fee`, `access_scope`, `is_active`) VALUES
(17, 1, 'gpa_record_access', 20, 'individual', 1),
(18, 1, 'thesis_sharing', 30, 'individual', 1),
(19, 1, 'course_information_sharing', 0, 'all', 1),
(20, 1, 'student_identity_authentication', 10, 'individual', 1);

-- --------------------------------------------------------

--
-- 表的结构 `service_authorizations`
--

CREATE TABLE `service_authorizations` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `authorized_workspace_id` int(11) NOT NULL COMMENT '被授权访问的workspace'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `t_admins`
--

CREATE TABLE `t_admins` (
  `id` int(11) NOT NULL,
  `managed_admins` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`managed_admins`)),
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `t_admins`
--

INSERT INTO `t_admins` (`id`, `managed_admins`, `last_login`) VALUES
(4, NULL, '2025-05-04 12:50:04');

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(120) NOT NULL,
  `user_name` varchar(80) NOT NULL,
  `password` varchar(128) NOT NULL DEFAULT '12345',
  `role` enum('O-Convener','E-Admin','T-Admin','DataUser','User') NOT NULL,
  `is_logged_in` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `verification_code` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `email`, `user_name`, `password`, `role`, `is_logged_in`, `created_at`, `verification_code`) VALUES
(2, 'ljt@qq.com', 'ljt', '12345', 'O-Convener', 0, '2025-05-04 16:20:52', 'MPXRS1'),
(3, 'eadmin@qq.com', 'eadmin', '12345', 'E-Admin', 0, '2025-05-04 20:17:15', NULL),
(4, 'tadmin@qq.com', 'tadmin', '12345', 'T-Admin', 0, '2025-05-04 20:17:38', NULL),
(5, 'okk@qq.com', 'okk', '12345', 'User', 0, '2025-05-04 21:51:16', 'NUX17G'),
(6, 'heleb@qq.com', 'heleb', '12345', 'User', 0, '2025-05-12 11:14:18', '2CEE8K'),
(21, 'three@qq.com', 'three', '12345', 'DataUser', 0, '2025-05-13 22:30:26', ''),
(74, 'ww@qq.com', 'ww', '12345', 'DataUser', 0, '2025-05-15 23:46:52', ''),
(75, 'arvupk694210@outlook.com', 'we', '12345', 'DataUser', 0, '2025-05-15 23:49:09', ''),
(82, 'Alice_Huang@uic.edu.cn', 'Alice Huang', '12345', 'DataUser', 0, '2025-05-16 16:46:56', ''),
(83, 'John_Chow@uic.edu.cn', 'John Chow', '12345', 'DataUser', 0, '2025-05-16 16:46:56', ''),
(84, 'Hb@qq.com', 'Heleb', '12345', 'DataUser', 0, '2025-05-16 16:46:56', '');

-- --------------------------------------------------------

--
-- 表的结构 `workspaces`
--

CREATE TABLE `workspaces` (
  `id` int(11) NOT NULL,
  `registration_application_id` int(11) DEFAULT NULL,
  `organization_full_name` varchar(255) NOT NULL,
  `organization_short_name` varchar(80) NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `workspaces`
--

INSERT INTO `workspaces` (`id`, `registration_application_id`, `organization_full_name`, `organization_short_name`, `created_at`) VALUES
(1, 11, 'happyplace', 'hp', '2025-05-05 15:22:41');

--
-- 转储表的索引
--

--
-- 表的索引 `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workspace_id` (`workspace_id`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `api_config`
--
ALTER TABLE `api_config`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workspace_id` (`workspace_id`);

--
-- 表的索引 `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `data_users`
--
ALTER TABLE `data_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_data_users_workspace_id` (`workspace_id`);

--
-- 表的索引 `e_admin`
--
ALTER TABLE `e_admin`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `membership_pricing`
--
ALTER TABLE `membership_pricing`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workspace_id` (`workspace_id`);

--
-- 表的索引 `member_policies`
--
ALTER TABLE `member_policies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workspace_id` (`workspace_id`);

--
-- 表的索引 `oconveners`
--
ALTER TABLE `oconveners`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `registration_application_id` (`registration_application_id`),
  ADD UNIQUE KEY `workspace_id` (`workspace_id`);

--
-- 表的索引 `payment_records`
--
ALTER TABLE `payment_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `registration_applications`
--
ALTER TABLE `registration_applications`
  ADD PRIMARY KEY (`application_id`);

--
-- 表的索引 `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workspace_id` (`workspace_id`);

--
-- 表的索引 `service_authorizations`
--
ALTER TABLE `service_authorizations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `authorized_workspace_id` (`authorized_workspace_id`);

--
-- 表的索引 `t_admins`
--
ALTER TABLE `t_admins`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- 表的索引 `workspaces`
--
ALTER TABLE `workspaces`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `registration_application_id` (`registration_application_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- 使用表AUTO_INCREMENT `api_config`
--
ALTER TABLE `api_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 使用表AUTO_INCREMENT `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `membership_pricing`
--
ALTER TABLE `membership_pricing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `member_policies`
--
ALTER TABLE `member_policies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `payment_records`
--
ALTER TABLE `payment_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `registration_applications`
--
ALTER TABLE `registration_applications`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- 使用表AUTO_INCREMENT `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- 使用表AUTO_INCREMENT `service_authorizations`
--
ALTER TABLE `service_authorizations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- 使用表AUTO_INCREMENT `workspaces`
--
ALTER TABLE `workspaces`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 限制导出的表
--

--
-- 限制表 `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`),
  ADD CONSTRAINT `activity_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- 限制表 `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD CONSTRAINT `bank_accounts_ibfk_1` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`);

--
-- 限制表 `data_users`
--
ALTER TABLE `data_users`
  ADD CONSTRAINT `data_users_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_data_users_workspace_id` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`);

--
-- 限制表 `e_admin`
--
ALTER TABLE `e_admin`
  ADD CONSTRAINT `e_admin_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`);

--
-- 限制表 `membership_pricing`
--
ALTER TABLE `membership_pricing`
  ADD CONSTRAINT `membership_pricing_ibfk_1` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`);

--
-- 限制表 `member_policies`
--
ALTER TABLE `member_policies`
  ADD CONSTRAINT `member_policies_ibfk_1` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`);

--
-- 限制表 `oconveners`
--
ALTER TABLE `oconveners`
  ADD CONSTRAINT `oconveners_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `oconveners_ibfk_2` FOREIGN KEY (`registration_application_id`) REFERENCES `registration_applications` (`application_id`),
  ADD CONSTRAINT `oconveners_ibfk_3` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`);

--
-- 限制表 `payment_records`
--
ALTER TABLE `payment_records`
  ADD CONSTRAINT `payment_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- 限制表 `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- 限制表 `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_ibfk_1` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`);

--
-- 限制表 `service_authorizations`
--
ALTER TABLE `service_authorizations`
  ADD CONSTRAINT `service_authorizations_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  ADD CONSTRAINT `service_authorizations_ibfk_2` FOREIGN KEY (`authorized_workspace_id`) REFERENCES `workspaces` (`id`);

--
-- 限制表 `t_admins`
--
ALTER TABLE `t_admins`
  ADD CONSTRAINT `t_admins_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`);

--
-- 限制表 `workspaces`
--
ALTER TABLE `workspaces`
  ADD CONSTRAINT `workspaces_ibfk_1` FOREIGN KEY (`registration_application_id`) REFERENCES `registration_applications` (`application_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
