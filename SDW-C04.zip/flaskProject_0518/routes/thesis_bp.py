from flask import Blueprint, jsonify, request, render_template
from models.user import DataUser, db
from models.workspace import APIConfig
from services import get_api_config, call_external_api

thesis_bp = Blueprint('thesis_bp', __name__)

@thesis_bp.route('/dataUser_dashBorad/thesis_search.html')
def thesis_search_page():
    return render_template('dataUser_dashBorad/thesis_search.html')

@thesis_bp.route('/api/thesis/search')
def search_thesis():
    try:
        query = request.args.get('query')
        user_id = request.args.get('userId')

        if not query or not user_id:
            return jsonify({"error": "Missing required parameters"}), 400

        # Get user's workspace
        data_user = DataUser.query.get(user_id)
        if not data_user:
            return jsonify({"error": "User not found"}), 404

        # Get API configuration for thesis search
        config = APIConfig.query.filter_by(
            workspace_id=data_user.workspace_id,
            service_type='thesis_search'
        ).first()

        if not config:
            return jsonify({"error": "Thesis search service not configured"}), 404

        # Prepare request data
        request_data = {
            'query': query,
            'service_type': 'thesis_search',
            'workspace_id': data_user.workspace_id
        }

        # Call the configured external API
        result = call_external_api(config, request_data)
        
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@thesis_bp.route('/api/thesis/view/<thesis_id>')
def view_thesis(thesis_id):
    try:
        user_id = request.args.get('userId')
        if not user_id:
            return jsonify({"error": "User ID is required"}), 400

        # Get user's workspace
        data_user = DataUser.query.get(user_id)
        if not data_user:
            return jsonify({"error": "User not found"}), 404

        # Get API configuration for thesis download
        config = APIConfig.query.filter_by(
            workspace_id=data_user.workspace_id,
            service_type='thesis_download'
        ).first()

        if not config:
            return jsonify({"error": "Thesis download service not configured"}), 404

        # Prepare request data
        request_data = {
            'thesis_id': thesis_id,
            'service_type': 'thesis_download',
            'workspace_id': data_user.workspace_id
        }

        # Call the configured external API
        result = call_external_api(config, request_data)
        
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500 