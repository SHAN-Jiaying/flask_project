from flask import Blueprint, request, render_template, jsonify, session, redirect, abort, app,current_app
from models.user import users,OConvener,RegistrationApplication,db
import os, random,string
from datetime import datetime
from flask_login import current_user, login_required
from models.workspace import UserNotification



auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/auth/send_verification_code", methods=["POST"])
def send_verification_code():
    email = request.json.get("email")
    # 检查用户是否存在且角色是User
    user = users.query.filter_by(email=email, role='User').first()
    if not user:
        return jsonify({"success": False, "message": "邮箱无效"}), 400

    # 生成6位随机验证码
    verification_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    user.verification_code = verification_code
    db.session.commit()
    db.session.refresh(current_user)

    return jsonify({"success": True, "message": "验证码已更新"})

@auth_bp.route("/auth/register", methods=["POST"])
def register_submit():
    # 获取表单数据和验证码
    org_name = request.form["org_name"]
    org_short = request.form["org_short"]
    email = request.form["email"]
    user_code = request.form.get("verification_code")
    proof_doc = request.files["proof_doc"]

    # 检查重复提交（基于邮箱）
    existing_application = RegistrationApplication.query.filter_by(application_email=email).first()
    if existing_application:
        return jsonify({"message": "You have already submitted the application. Please do not submit it again."}), 400


    # 检查已批准的机构全称
    if RegistrationApplication.query.filter(
            RegistrationApplication.organization_full_name == org_name,
            RegistrationApplication.status == 'Approved'

    ).first():
        return jsonify({"message": "The full name of the institution has been used. Please change to another name."}), 400

    # 检查已批准的机构简称
    if RegistrationApplication.query.filter(
            RegistrationApplication.organization_short_name == org_short,
            RegistrationApplication.status == 'Approved'



    ).first():
        return jsonify({"message": "The abbreviated name of the institution has been used. Please change to another name."}), 400

    # 验证验证码
    user = users.query.filter_by(email=email).first()
    if not user or user.verification_code != user_code:
        return jsonify({"message": "Invalid verification code"}), 400

    # 创建上传目录（新增代码）
    upload_dir = current_app.config['UPLOAD_FOLDER']
    os.makedirs(upload_dir, exist_ok=True)

    # 保存文件（路径改为绝对路径）
    filename = os.path.join(upload_dir, f"{email.replace('@', '_')}.pdf")
    proof_doc.save(filename)

    # 创建注册申请
    new_application = RegistrationApplication(
        application_email=email,
        organization_full_name=request.form["org_name"],
        organization_short_name=request.form["org_short"],
        proof_document=filename,
        status='Pending Initial Review',
        submission_time=datetime.now()
    )
    db.session.add(new_application)

    db.session.commit()

    return jsonify({"message": "Registration submitted successfully"}),200


@auth_bp.route("/auth/check_org")
def check_org_availability():
    check_type = request.args.get("type")
    name = request.args.get("name")

    exists = RegistrationApplication.query.filter(
        getattr(RegistrationApplication,
                f"organization_{'full' if check_type == 'full' else 'short'}_name") == name,
        RegistrationApplication.status == 'Approved'
    ).first()

    return jsonify({"available": not exists})


@auth_bp.route("/api/get_user_role")
def get_user_role():
    user_id = request.args.get("user_id")
    if not user_id:
        return jsonify({"success": False, "message": "Missing user ID"}), 400

    user = users.query.get(user_id)
    if not user:
        return jsonify({"success": False, "message": "User not found"}), 404

    return jsonify({
        "success": True,
        "role": user.role,
        "normalized_role": user.role.lower().replace(' ', '')  # 规范化角色名称
    })

@auth_bp.route("/auth/review_application", methods=["POST"])
def review_application():
    try:
        data = request.get_json()
        application_id = data.get('application_id')
        action = data.get('action')
        reason = data.get('reason')

        if not application_id or not action:
            return jsonify({"success": False, "message": "Missing required fields"}), 400

        # 获取申请记录
        application = RegistrationApplication.query.get_or_404(application_id)
        
        # 获取申请人用户记录
        user = users.query.filter_by(email=application.application_email).first()
        if not user:
            return jsonify({"success": False, "message": "User not found"}), 404

        # 更新申请状态
        if action == 'pass':
            application.status = 'Pending Final Review'
            notification_subject = "Application Status Update"
            notification_message = f"Your application for {application.organization_full_name} has passed the initial review and is now pending final review."
        elif action == 'reject':
            if not reason:
                return jsonify({"success": False, "message": "Rejection reason is required"}), 400
            application.status = 'Rejected'
            application.rejection_reason = reason
            notification_subject = "Application Rejected"
            notification_message = f"Your application for {application.organization_full_name} has been rejected. Reason: {reason}"
        else:
            return jsonify({"success": False, "message": "Invalid action"}), 400

        # 创建通知
        notification = UserNotification(
            user_id=user.id,
            subject=notification_subject,
            message=notification_message
        )
        db.session.add(notification)
        
        # 更新最后处理时间
        application.last_processed_time = datetime.now()
        
        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Application reviewed successfully",
            "status": application.status
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": str(e)}), 500

@auth_bp.route("/auth/get_applications")
def get_applications():
    try:
        # 获取所有申请记录，按提交时间倒序排列
        applications = RegistrationApplication.query.order_by(
            RegistrationApplication.submission_time.desc()
        ).all()
        
        return jsonify({
            "success": True,
            "applications": [{
                "application_id": app.application_id,
                "organization_full_name": app.organization_full_name,
                "organization_short_name": app.organization_short_name,
                "application_email": app.application_email,
                "status": app.status,
                "submission_time": app.submission_time.strftime('%Y-%m-%d %H:%M:%S'),
                "rejection_reason": app.rejection_reason
            } for app in applications]
        })
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@auth_bp.route("/auth/test_applications")
def test_applications():
    try:
        # 获取所有申请记录
        applications = RegistrationApplication.query.all()
        
        # 打印调试信息
        print(f"Total applications found: {len(applications)}")
        for app in applications:
            print(f"Application ID: {app.application_id}")
            print(f"Organization: {app.organization_full_name}")
            print(f"Email: {app.application_email}")
            print(f"Status: {app.status}")
            print("---")
        
        return jsonify({
            "success": True,
            "count": len(applications),
            "applications": [{
                "id": app.application_id,
                "org": app.organization_full_name,
                "email": app.application_email,
                "status": app.status
            } for app in applications]
        })
    except Exception as e:
        print(f"Error in test_applications: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 500

@auth_bp.route("/auth/final_review_application", methods=["POST"])
def final_review_application():
    try:
        data = request.get_json()
        application_id = data.get('application_id')
        action = data.get('action')
        reason = data.get('reason')

        if not application_id or not action:
            return jsonify({"success": False, "message": "Missing required fields"}), 400

        # 获取申请记录
        application = RegistrationApplication.query.get_or_404(application_id)
        
        # 获取申请人用户记录
        user = users.query.filter_by(email=application.application_email).first()
        if not user:
            return jsonify({"success": False, "message": "User not found"}), 404

        # 更新申请状态
        if action == 'pass':
            application.status = 'Approved'
            notification_subject = "Application Approved"
            notification_message = f"Your application for {application.organization_full_name} has been approved. You can now proceed with the next steps."
        elif action == 'reject':
            if not reason:
                return jsonify({"success": False, "message": "Rejection reason is required"}), 400
            application.status = 'Rejected'
            application.rejection_reason = reason
            notification_subject = "Application Rejected"
            notification_message = f"Your application for {application.organization_full_name} has been rejected. Reason: {reason}"
        else:
            return jsonify({"success": False, "message": "Invalid action"}), 400

        # 创建通知
        notification = UserNotification(
            user_id=user.id,
            subject=notification_subject,
            message=notification_message
        )
        db.session.add(notification)
        
        # 更新最后处理时间
        application.last_processed_time = datetime.now()
        
        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Application reviewed successfully",
            "status": application.status
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": str(e)}), 500

@auth_bp.route("/E_Admin/se-admin-application-list.html")
def se_admin_application_list():
    try:
        user_id = request.args.get('id')
        if not user_id:
            abort(400, "Missing user ID")

        # 验证用户是否为Senior E-Admin
        user = users.query.get(user_id)
        if not user or user.role != 'SE-Admin':
            abort(403, "Unauthorized access - Not a Senior E-Admin")

        # 获取所有待最终审核和已批准的申请记录
        applications = RegistrationApplication.query.filter(
            RegistrationApplication.status.in_(['Pending Final Review', 'Approved'])
        ).order_by(RegistrationApplication.submission_time.desc()).all()
        
        return render_template('E_Admin/se-admin-application-list.html',
                             user_id=user_id,
                             applications=applications)
    except Exception as e:
        print(f"Error in se_admin_application_list: {str(e)}")
        abort(500, str(e))

@auth_bp.route("/E_Admin/assign_workspaces.html")
def assign_workspaces():
    try:
        user_id = request.args.get('id')
        if not user_id:
            abort(400, "Missing user ID")

        # 验证用户是否为Senior E-Admin
        user = users.query.get(user_id)
        if not user or user.role != 'SE-Admin':
            abort(403, "Unauthorized access - Not a Senior E-Admin")

        # 获取所有已批准的申请记录，并关联用户信息
        applications = RegistrationApplication.query.filter(
            RegistrationApplication.status == 'Approved'
        ).options(
            db.joinedload(RegistrationApplication.user)
        ).order_by(RegistrationApplication.submission_time.desc()).all()
        
        # 打印调试信息
        print(f"Found {len(applications)} approved applications")
        for app in applications:
            print(f"Application ID: {app.application_id}")
            print(f"Email: {app.application_email}")
            print(f"User: {app.user.user_name if app.user else 'No user found'}")
            print("---")
        
        # 过滤掉没有找到用户的申请
        valid_applications = [app for app in applications if app.user is not None]
        
        return render_template('E_Admin/assign_workspaces.html',
                             user_id=user_id,
                             applications=valid_applications)
    except Exception as e:
        print(f"Error in assign_workspaces: {str(e)}")
        abort(500, str(e))

@auth_bp.route("/auth/assign_workspace", methods=["POST"])
def assign_workspace():
    try:
        data = request.get_json()
        application_id = data.get('application_id')
        user_id = data.get('user_id')

        if not application_id or not user_id:
            return jsonify({"success": False, "message": "Missing required fields"}), 400

        # 获取申请记录
        application = RegistrationApplication.query.get_or_404(application_id)
        
        # 验证申请状态
        if application.status != 'Approved':
            return jsonify({"success": False, "message": "Application is not approved"}), 400

        # 检查是否已经分配了工作空间
        if application.workspace:
            return jsonify({"success": False, "message": "Workspace already assigned"}), 400

        # 获取并更新用户角色
        user = users.query.get(user_id)
        if not user:
            return jsonify({"success": False, "message": "User not found"}), 404
        
        # 更新用户角色为O-Convener
        user.role = 'O-Convener'

        # 创建新的工作空间
        from models.workspace import Workspace
        new_workspace = Workspace(
            registration_application_id=application_id,
            organization_full_name=application.organization_full_name,
            organization_short_name=application.organization_short_name,
            created_at=datetime.utcnow()
        )
        db.session.add(new_workspace)
        db.session.flush()  # 获取新工作空间的ID

        # 创建O-Convener记录
        oconvener = OConvener(
            id=user_id,
            registration_application_id=application_id,
            workspace_id=new_workspace.id
        )
        db.session.add(oconvener)

        # 创建通知
        notification = UserNotification(
            user_id=user_id,
            subject="Workspace Assigned and Role Updated",
            message=f"A workspace has been assigned for your organization: {application.organization_full_name}. Your role has been updated to O-Convener."
        )
        db.session.add(notification)

        # 提交所有更改
        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Workspace assigned and role updated successfully"
        })

    except Exception as e:
        db.session.rollback()
        print(f"Error in assign_workspace: {str(e)}")  # 添加错误日志
        return jsonify({"success": False, "message": str(e)}), 500

