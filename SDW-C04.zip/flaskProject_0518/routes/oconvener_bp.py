import traceback
from uuid import uuid4

import requests
from flask import Blueprint, request, render_template, jsonify, session, redirect, abort, current_app, url_for
from sqlalchemy import DECIMAL
from werkzeug.security import generate_password_hash, check_password_hash  # 新增generate_password_hash
import random
import string

from models.user import db, OConvener, DataUser, users
from models.workspace import Service, Workspace, BankAccount, MembershipPricing, PaymentRecord
import os, random, string
from datetime import datetime
from flask_login import current_user, login_required
import openpyxl
from sqlalchemy.exc import IntegrityError
from utils.activity_logger import get_activity_logs

oconvener_bp = Blueprint('oconvener', __name__)


@oconvener_bp.route('/api/oconveners/<int:user_id>')
@login_required
def get_oconvener(user_id):
    try:
        # Verify the requesting user is the same as the requested user_id
        if current_user.id != user_id:
            return jsonify({"error": "Unauthorized access"}), 403

        oconvener = OConvener.query.filter_by(id=user_id).first()
        if not oconvener:
            return jsonify({"error": "O-Convener not found"}), 404

        return jsonify({
            'id': oconvener.id,
            'workspace_id': oconvener.workspace_id
        })
    except Exception as e:
        print(f"Error in get_oconvener: {str(e)}")
        return jsonify({"error": "Failed to get O-Convener information"}), 500


@oconvener_bp.route('/api/services', methods=['GET', 'POST', 'DELETE'])
@login_required
def manage_services():
    workspace_id = request.args.get('workspace_id')  # 添加这行
    service_id = request.args.get('id')  # 获取单个服务的ID
    if not workspace_id:
        return jsonify({"error": "Missing workspace_id"}), 400

    if request.method == 'GET':
        if service_id:  # 处理单个服务请求
            service = Service.query.filter_by(id=service_id, workspace_id=workspace_id).first()
            if not service:
                return jsonify({"error": "Service not found"}), 404
            return jsonify(service.to_dict())
        else:  # 处理所有服务列表
            services = Service.query.filter_by(workspace_id=workspace_id).all()
            return jsonify([s.to_dict() for s in services])

    elif request.method == 'POST':
        # 添加新服务
        data = request.json
        required_fields = ['service_type', 'fee', 'access_scope']
        if not all(field in data for field in required_fields):
            return jsonify({"error": "Missing required fields"}), 400
        try:
            new_service = Service(
                workspace_id=workspace_id,
                service_type=data['service_type'],
                fee=float(data['fee']),
                access_scope=data['access_scope'],
                is_active=True
            )
            db.session.add(new_service)
            db.session.commit()
            return jsonify({"id": new_service.id}), 201
        except ValueError:
            return jsonify({"error": "Invalid fee format"}), 400


    elif request.method == 'DELETE':

        service_id = request.args.get('id')
        if not service_id:
            return jsonify({"error": "Missing service ID"}), 400
        service = Service.query.filter_by(id=service_id, workspace_id=workspace_id).first()
        if not service:
            return jsonify({"error": "Service not found"}), 404

        db.session.delete(service)
        db.session.commit()
        return jsonify({"message": "Service deleted"}), 200


@oconvener_bp.route('/api/services/<int:service_id>', methods=['PUT'])
@login_required
def update_service(service_id):
    # 获取当前用户的workspace_id
    o_convener = OConvener.query.filter_by(id=current_user.id).first()
    if not o_convener or not o_convener.workspace_id:
        return jsonify({"error": "Workspace not found"}), 404

    service = Service.query.filter_by(id=service_id, workspace_id=o_convener.workspace_id).first()
    if not service:
        return jsonify({"error": "Service not found"}), 404

    data = request.json
    try:
        if 'fee' in data:
            service.fee = float(data['fee'])
        if 'access_scope' in data:
            service.access_scope = data['access_scope']
        db.session.commit()
        return jsonify({"message": "Service updated"}), 200
    except ValueError:
        return jsonify({"error": "Invalid data format"}), 400


# =========load  Membership charging standards table================================================
@oconvener_bp.route('/api/membership_pricing', methods=['GET'])
@login_required
def get_pricing():
    workspace_id = request.args.get('workspace_id')
    rows = MembershipPricing.query.filter_by(workspace_id=workspace_id).all()
    return jsonify([{'id': r.id, 'access_right': r.access_right, 'price': r.price} for r in rows])


@oconvener_bp.route('/api/membership_pricing/<int:pricing_id>', methods=['PUT'])
@login_required
def update_pricing(pricing_id):
    data = request.get_json()
    row = MembershipPricing.query.get(pricing_id)
    if not row:
        return jsonify({'error': 'not found'}), 404
    row.price = float(data['price'])
    db.session.commit()
    return jsonify({'message': 'updated'})


# =========load  Membership charging standards table==================================================


@oconvener_bp.route('/workspace/accountManagement')
@login_required
def account_management():
    # 获取当前用户的O-Convener记录
    o_convener = OConvener.query.filter_by(id=current_user.id).first()
    if not o_convener or not o_convener.workspace_id:
        abort(404, "Workspace not found")

    # 获取关联的工作空间信息
    workspace = Workspace.query.get(o_convener.workspace_id)
    bank_account = BankAccount.query.filter_by(workspace_id=o_convener.workspace_id).first()

    return render_template('/workspace/accountManagement.html',
                           organization_full_name=workspace.organization_full_name,
                           organization_short_name=workspace.organization_short_name,
                           bank_account=bank_account)


@oconvener_bp.route('/api/members', methods=['GET', 'POST', 'DELETE'])
@login_required
def manage_members():
    # 获取当前O-Convener的workspace
    o_convener = OConvener.query.filter_by(id=current_user.id).first()
    if not o_convener or not o_convener.workspace_id:
        return jsonify({"error": "Workspace not found"}), 404

    workspace_id = o_convener.workspace_id

    if request.method == 'GET':
        member_id = request.args.get('member_id')  # 新增参数

        # 处理单个成员请求
        if member_id:
            # 验证成员是否属于当前workspace
            data_user = DataUser.query.filter_by(
                id=member_id,
                workspace_id=workspace_id
            ).first()

            if not data_user:
                return jsonify({"error": "Member not found"}), 404

            user = users.query.get(member_id)
            return jsonify({
                'id': user.id,
                'name': user.user_name,
                'email': user.email,
                'access_rights': data_user.access_rights,
                'payment_quota': data_user.payment_quota,
                'last_access': data_user.last_access.isoformat() if data_user.last_access else None
            })

        # 处理所有成员列表
        members = db.session.query(users, DataUser).join(
            DataUser, users.id == DataUser.id
        ).filter(
            DataUser.workspace_id == workspace_id
        ).all()

        return jsonify([{
            'id': user.id,
            'name': user.user_name,
            'email': user.email,
            'access_rights': data_user.access_rights,
            'payment_quota': data_user.payment_quota,
            'last_access': data_user.last_access.isoformat() if data_user.last_access else None
        } for user, data_user in members])

    elif request.method == 'POST':
        data = request.json
        if not all(key in data for key in ['email', 'name', 'access_rights', 'payment_quota']):
            return jsonify({"error": "Missing required fields"}), 400

        access_right = int(data['access_rights'])
        quota = float(data['payment_quota'])

        price_entry = MembershipPricing.query.filter_by(workspace_id=workspace_id, access_right=access_right).first()
        if not price_entry:
            return jsonify({'error': '未找到对应的会员费用配置'}), 400
        price = price_entry.price

        bank = BankAccount.query.filter_by(workspace_id=workspace_id).first()
        if not bank:
            return jsonify({'error': '未配置银行账户'}), 400

        payload = {
            "from_bank": bank.bank,
            "from_name": bank.account_name,
            "from_account": bank.account_number,
            "password": bank.password,
            "to_bank": TARGET_BANK_ACCOUNT["bank"],
            "to_name": TARGET_BANK_ACCOUNT["name"],
            "to_account": TARGET_BANK_ACCOUNT["account"],
            "amount": int(price)
        }

        try:
            response = requests.post(f"{BANK_API_BASE}/hw/bank/transfer", json=payload)
            result = response.json()
            if result.get("status") != "success":
                return jsonify({'error': f"转账失败：{result.get('reason', '未知错误')}"}), 400
        except Exception as e:
            return jsonify({'error': f"银行接口调用失败: {str(e)}"}), 500

        new_user = users(
            email=data['email'],
            user_name=data['name'],
            password='12345',
            role='DataUser',
            verification_code=''
        )
        db.session.add(new_user)
        db.session.flush()

        new_data_user = DataUser(
            id=new_user.id,
            workspace_id=workspace_id,
            access_rights=access_right,
            payment_quota=quota
        )
        db.session.add(new_data_user)

        pay = PaymentRecord(
            user_id=new_user.id,
            amount=price,
            payment_method='external_bank_api',
            payment_date=datetime.utcnow()
        )
        db.session.add(pay)
        db.session.commit()

        return jsonify({"id": new_user.id}), 201

    elif request.method == 'DELETE':
        member_id = request.args.get('member_id')
        if not member_id:
            return jsonify({"error": "Missing member ID"}), 400

        # 验证成员是否属于当前workspace
        data_user = DataUser.query.filter_by(
            id=member_id,
            workspace_id=workspace_id  # 添加workspace验证
        ).first()

        if not data_user:
            return jsonify({"error": "Member not found in workspace"}), 404

        # 级联删除
        db.session.delete(data_user)
        db.session.query(users).filter_by(id=member_id).delete()
        db.session.commit()
        return jsonify({"message": "Member deleted"}), 200


@oconvener_bp.route('/api/members/<int:member_id>', methods=['PUT'])
@login_required
def update_member(member_id):
    # 获取当前用户的workspace_id
    o_convener = OConvener.query.filter_by(id=current_user.id).first()
    if not o_convener or not o_convener.workspace_id:
        return jsonify({"error": "Workspace not found"}), 404
    workspace_id = o_convener.workspace_id

    # 验证成员属于当前workspace
    data_user = DataUser.query.filter_by(id=member_id, workspace_id=workspace_id).first()
    if not data_user:
        return jsonify({"error": "Member not found in workspace"}), 404

    # 获取用户记录
    user = users.query.get(member_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.json
    try:
        # 更新用户信息
        if 'name' in data:
            user.user_name = data['name']
        if 'email' in data:
            # 检查email是否已存在
            existing_user = users.query.filter(users.email == data['email'], users.id != member_id).first()
            if existing_user:
                return jsonify({"error": "Email already in use"}), 400
            user.email = data['email']
        if 'access_rights' in data:
            data_user.access_rights = data['access_rights']
        if 'payment_quota' in data:
            data_user.payment_quota = data['payment_quota']

        db.session.commit()
        return jsonify({"message": "Member updated successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


@oconvener_bp.route('/api/members/upload', methods=['POST'])
@login_required
def bulk_import_members():
    # 获取当前用户的workspace
    o_convener = OConvener.query.filter_by(id=current_user.id).first()
    if not o_convener or not o_convener.workspace_id:
        return jsonify({"error": "Workspace not found"}), 404

    # 检查文件是否存在
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    file = request.files['file']

    # 验证文件格式
    if not file.filename.endswith(('.xlsx', '.xls')):
        return jsonify({"error": "Only Excel files are supported (.xlsx, .xls)"}), 400

    try:
        wb = openpyxl.load_workbook(file)
        sheet = wb.active

        # 验证表头
        headers = [cell.value for cell in sheet[1]]
        required_headers = ['user_name', 'email', 'access_right', 'payment_quota']
        if not all(h in headers for h in required_headers):
            return jsonify({"error": "The necessary header fields are missing in Excel."}), 400

        # 遍历数据行
        success_count = 0
        errors = []
        for row in sheet.iter_rows(min_row=2, values_only=True):  # 从第二行开始
            data = dict(zip(headers, row))

            # 数据校验
            if not all(data[key] for key in required_headers):
                errors.append(f"row{row[0]}：Missing necessary fields")
                continue

            try:
                # 检查邮箱是否已存在
                if users.query.filter_by(email=data['email']).first():
                    errors.append(f"email {data['email']} Already exists")
                    continue

                # 创建用户
                new_user = users(
                    email=data['email'],
                    user_name=data['user_name'],
                    password='12345',
                    role='DataUser'
                )
                db.session.add(new_user)
                db.session.flush()  # 获取生成的ID

                # 创建DataUser
                new_data_user = DataUser(
                    id=new_user.id,
                    workspace_id=o_convener.workspace_id,
                    access_rights=int(data['access_right']),
                    payment_quota=float(data['payment_quota'])
                )
                db.session.add(new_data_user)

                success_count += 1

            except (ValueError, TypeError) as e:
                errors.append(f"行{row[0]}：数据格式错误")
                db.session.rollback()

        db.session.commit()

        return jsonify({
            "message": f"成功导入 {success_count} 条记录",
            "errors": errors
        }), 200

    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Bulk import error: {str(e)}")
        return jsonify({"error": "文件解析失败，请检查Excel格式"}), 500


@oconvener_bp.route('/api/services/<int:service_id>/fee', methods=['PUT'])
@login_required
def set_service_fee(service_id):
    # 获取当前用户的workspace_id
    o_convener = OConvener.query.filter_by(id=current_user.id).first()
    if not o_convener or not o_convener.workspace_id:
        return jsonify({"error": "Workspace not found"}), 404

    service = Service.query.filter_by(id=service_id, workspace_id=o_convener.workspace_id).first()
    if not service:
        return jsonify({"error": "Service not found"}), 404

    data = request.json
    try:
        if 'fee' in data:
            service.fee = DECIMAL(data['fee'])
        db.session.commit()
        return jsonify({"message": "Service fee updated"}), 200
    except ValueError:
        return jsonify({"error": "Invalid data format"}), 400


PREVIEW_CACHE = {}
BANK_API_BASE = "http://172.16.160.88:8001"
TARGET_BANK_ACCOUNT = {
    "bank": "E-DBA Bank",
    "account": "596117071864958",
    "name": "E-DBA account"
}


@oconvener_bp.route('/api/members/preview-upload', methods=['POST'])
@login_required
def preview_member_upload():
    o_convener = OConvener.query.filter_by(id=current_user.id).first()
    if not o_convener:
        return jsonify({"error": "O-Convener not found"}), 404

    file = request.files.get('file')
    if not file or not file.filename.endswith(('.xlsx', '.xls')):
        return jsonify({"error": "Please upload a valid Excel file."}), 400

    try:
        wb = openpyxl.load_workbook(file)
        sheet = wb.active
        headers = [cell.value for cell in sheet[1]]
        required = ['user_name', 'email', 'access_right', 'payment_quota']
        if not all(h in headers for h in required):
            return jsonify({"error": "The necessary header fields are missing in Excel."}), 400

        pricing_map = {p.access_right: p.price for p in
                       MembershipPricing.query.filter_by(workspace_id=o_convener.workspace_id)}
        counts = {"1": 0, "2": 0, "3": 0}
        members = []
        total = 0

        for row in sheet.iter_rows(min_row=2, values_only=True):
            row_data = dict(zip(headers, row))
            right = str(row_data['access_right'])
            if right not in counts:
                continue
            counts[right] += 1
            total += pricing_map.get(int(right), 0.0)
            members.append(row_data)

        preview_id = str(uuid4())
        PREVIEW_CACHE[preview_id] = {
            'members': members,
            'total_price': total,
            'workspace_id': o_convener.workspace_id,
            'created_at': datetime.utcnow(),
            'user_id': current_user.id
        }
        return jsonify({"counts": counts, "total_price": total, "preview_id": preview_id})

    except Exception as e:
        return jsonify({"error": f"File processing failed: {str(e)}"}), 500


@oconvener_bp.route('/api/members/confirm-upload/<string:preview_id>', methods=['POST'])
@login_required
def confirm_member_upload(preview_id):
    print(f"Starting confirm_member_upload for preview_id: {preview_id}")  # Debug log
    
    preview = PREVIEW_CACHE.get(preview_id)
    if not preview:
        print(f"Invalid or expired preview_id: {preview_id}")  # Debug log
        return jsonify({"success": False, "message": "无效或已过期的预览ID"}), 400

    workspace_id = preview['workspace_id']
    members = preview['members']
    total_price = preview['total_price']
    user_id = preview['user_id']

    print(f"Processing workspace_id: {workspace_id}, total_price: {total_price}")  # Debug log

    # 检查银行账户
    bank = BankAccount.query.filter_by(workspace_id=workspace_id).first()
    if not bank:
        print(f"No bank account found for workspace_id: {workspace_id}")  # Debug log
        return jsonify({"success": False, "message": "未找到银行账户信息"}), 400

    try:
        # 准备转账数据
        payload = {
            "from_bank": bank.bank,
            "from_name": bank.account_name,
            "from_account": bank.account_number,
            "password": bank.password,
            "to_bank": TARGET_BANK_ACCOUNT["bank"],
            "to_name": TARGET_BANK_ACCOUNT["name"],
            "to_account": TARGET_BANK_ACCOUNT["account"],
            "amount": int(total_price)
        }
        print(f"Sending transfer request with payload: {payload}")  # Debug log

        # 调用银行接口
        response = requests.post(f"{BANK_API_BASE}/hw/bank/transfer", json=payload)
        print(f"Bank API response status: {response.status_code}")  # Debug log
        print(f"Bank API response content: {response.text}")  # Debug log
        
        try:
            result = response.json()
        except ValueError as e:
            print(f"Failed to parse bank API response: {e}")  # Debug log
            return jsonify({"success": False, "message": "银行接口返回格式错误"}), 500

        if result.get("status") != "success":
            error_msg = f"转账失败: {result.get('reason', '未知错误')}"
            print(error_msg)  # Debug log
            return jsonify({"success": False, "message": error_msg}), 400

    except requests.exceptions.RequestException as e:
        error_msg = f"转账接口调用异常: {str(e)}"
        print(error_msg)  # Debug log
        return jsonify({"success": False, "message": error_msg}), 500
    except Exception as e:
        error_msg = f"处理转账请求时发生错误: {str(e)}"
        print(error_msg)  # Debug log
        return jsonify({"success": False, "message": error_msg}), 500

    try:
        # 处理成员数据
        for m in members:
            print(f"Processing member: {m}")  # Debug log
            
            # 检查邮箱是否已存在
            if users.query.filter_by(email=m['email']).first():
                print(f"Email already exists: {m['email']}")  # Debug log
                continue

            # 创建新用户
            new_user = users(
                email=m['email'],
                user_name=m['user_name'],
                password='12345',
                role='DataUser'
            )
            db.session.add(new_user)
            db.session.flush()

            # 创建DataUser记录
            data_user = DataUser(
                id=new_user.id,
                workspace_id=workspace_id,
                access_rights=int(m['access_right']),
                payment_quota=float(m['payment_quota'])
            )
            db.session.add(data_user)

        # 创建支付记录
        payment_record = PaymentRecord(
            user_id=user_id,
            amount=total_price,
            payment_method='external_bank_api',
            detail='member added fee',
            payment_date=datetime.utcnow()
        )
        db.session.add(payment_record)

        # 提交事务
        db.session.commit()
        print("Transaction committed successfully")  # Debug log

        # 清理缓存
        del PREVIEW_CACHE[preview_id]
        return jsonify({"success": True, "message": "Members added successfully"})

    except Exception as e:
        print(f"Error processing members: {str(e)}")  # Debug log
        traceback.print_exc()
        db.session.rollback()
        return jsonify({"success": False, "message": f"处理成员数据时出错: {str(e)}"}), 500


# ====================处理单个会员加入，支付跳转=================
@oconvener_bp.route('/api/members/single-preview', methods=['POST'])
@login_required
def single_preview():
    data = request.get_json()
    o_convener = OConvener.query.filter_by(id=current_user.id).first()
    if not o_convener:
        return jsonify({"error": "O-Convener not found"}), 404

    workspace_id = o_convener.workspace_id
    access_right = int(data['access_rights'])

    # 查价格
    pricing = MembershipPricing.query.filter_by(workspace_id=workspace_id, access_right=access_right).first()
    if not pricing:
        return jsonify({"error": "未找到定价配置"}), 400

    amount = pricing.price

    preview_id = str(uuid4())
    PREVIEW_CACHE[preview_id] = {
        'members': [{
            'user_name': data['name'],
            'email': data['email'],
            'access_right': access_right,
            'payment_quota': data.get('payment_quota', 500.00)
        }],
        'total_price': amount,
        'workspace_id': workspace_id,
        'created_at': datetime.utcnow(),
        'user_id': current_user.id
    }
    return jsonify({"preview_id": preview_id})


@oconvener_bp.route('/api/activity-logs')
@login_required
def get_workspace_activity_logs():
    try:
        # Get workspace_id from query parameters
        workspace_id = request.args.get('workspace_id')
        if not workspace_id:
            return jsonify({'error': 'Workspace ID is required'}), 400

        # Convert to int for comparison
        workspace_id = int(workspace_id)

        # Get the O-Convener's workspace
        o_convener = OConvener.query.filter_by(id=current_user.id).first()
        if not o_convener:
            return jsonify({'error': 'Unauthorized access - Not an O-Convener'}), 403

        # Verify the O-Convener has access to this workspace
        if o_convener.workspace_id != workspace_id:
            return jsonify({'error': 'Unauthorized access - Wrong workspace'}), 403

        # Get filters from query parameters
        filters = {
            'activity_type': request.args.get('activity_type'),
            'username': request.args.get('username'),
            'date': request.args.get('date')
        }
        # Remove None values
        filters = {k: v for k, v in filters.items() if v is not None}

        # Get logs using the utility function
        logs = get_activity_logs(workspace_id, filters)

        return jsonify({
            'success': True,
            'logs': logs
        })

    except ValueError as e:
        return jsonify({
            'success': False,
            'error': 'Invalid workspace ID format'
        }), 400
    except Exception as e:
        print(f"Error in get_workspace_activity_logs: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve activity logs'
        }), 500


