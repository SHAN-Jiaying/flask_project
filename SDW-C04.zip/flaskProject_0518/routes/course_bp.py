
from flask import Blueprint, jsonify, request, abort, render_template, send_from_directory
from flask_login import login_required, current_user
from models.user import OConvener, DataUser,db
from models.workspace import Service,Course


course_bp = Blueprint('course_bp', __name__)

@course_bp.route('/api/courses/add', methods=['POST'])
def add_course():
    data = request.get_json()
    if not all(key in data for key in ['title', 'description', 'units']):
        return jsonify(success=False, message="Missing fields"), 400

    course = Course(title=data['title'], units=data['units'], description=data['description'])
    db.session.add(course)
    db.session.commit()
    return jsonify(success=True)

# 更新课程
@course_bp.route('/api/courses/update', methods=['POST'])
def update_course():
    data = request.get_json()
    course = Course.query.get(data.get('id'))
    if not course:
        return jsonify(success=False, message="Course not found"), 404

    course.title = data['title']
    course.units = data['units']
    course.description = data['description']
    db.session.commit()
    return jsonify(success=True)

# 获取课程列表
@course_bp.route('/api/courses/list', methods=['GET'])
def list_courses():
    courses = Course.query.all()
    return jsonify(courses=[c.to_dict() for c in courses])

@course_bp.route('/CourseAddPage.html')
def course_add_page():
    return render_template('/dataUser_dashBorad/CourseAddPage.html')  # 如果是 Jinja 模板


# 获取课程详情
@course_bp.route('/api/courses/detail', methods=['GET'])
def course_detail():
    course_id = request.args.get('id')
    course = Course.query.get(course_id)
    if not course:
        return jsonify(success=False, message="Course not found"), 404
    return jsonify(course.to_dict())

# 删除课程
@course_bp.route('/api/courses/delete', methods=['DELETE'])
def delete_course():
    course_id = request.args.get('id')
    course = Course.query.get(course_id)
    if not course:
        return jsonify(success=False, message="Course not found"), 404

    db.session.delete(course)
    db.session.commit()
    return jsonify(success=True)

# 搜搜课程
@course_bp.route('/api/courses/search', methods=['GET'])
def search_courses():
    keyword = request.args.get('keyword', '').strip()
    if not keyword:
        return jsonify(courses=[])

    courses = Course.query.filter(Course.title.ilike(f'%{keyword}%')).all()
    return jsonify(courses=[c.to_dict() for c in courses])



