import decimal
import traceback
from datetime import datetime

from flask import Blueprint, jsonify, request, abort, render_template, redirect, url_for
from flask_login import login_required, current_user
from models.user import OConvener, DataUser, db, users
from models.workspace import Service, Question, PaymentRecord, ActivityLog, Course, APIConfig, Policy, BankAccount
from sqlalchemy import func
from utils.activity_logger import log_activity

datauser_bp = Blueprint('datauser_bp', __name__)




@datauser_bp.route('/api/datauser/<int:user_id>/workspace')
@login_required
def get_datauser_workspace(user_id):
    data_user = DataUser.query.get(user_id)
    if not data_user:
        abort(404, description="User not found")
    return jsonify({
        'workspace_id': data_user.workspace_id,
        'access_rights': data_user.access_rights
    })


@datauser_bp.route('/api/questions')
@login_required
def get_questions():
    user_id = request.args.get('user_id')
    questions = Question.query.filter_by(user_id=user_id).order_by(Question.created_at.desc()).all()
    return jsonify([q.to_dict() for q in questions])


# 提交问题的API（修改原有路由）
@datauser_bp.route('/submit-question', methods=['POST'])
@login_required
def submit_question():
    try:
        data = request.get_json()
        new_question = Question(
            user_id=data['user_id'],
            title=data['title'],
            description=data['description'],
            date=data['date'],
            state='unanswered'
        )
        db.session.add(new_question)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500



@datauser_bp.route('/api/datauser/<int:user_id>/use_service/<int:service_id>', methods=['POST'])
@login_required
def use_service(user_id, service_id):
    data_user = DataUser.query.filter_by(id=user_id).first()
    if not data_user:
        return jsonify({"error": "Data user not found"}), 404

    service = Service.query.filter_by(id=service_id).first()
    if not service:
        return jsonify({"error": "Service not found"}), 404

    if float(data_user.balance) < float(service.fee):
        return jsonify({"error": "Insufficient balance"}), 400

    try:
        # 扣除费用
        data_user.balance = float(data_user.balance) - float(service.fee)

        # 记录支付记录
        payment_record = PaymentRecord(
            user_id=user_id,
            service_id=service_id,
            amount=float(service.fee),
            payment_method='System deduction'
        )
        db.session.add(payment_record)

        # Log the activity
        log_activity(
            workspace_id=data_user.workspace_id,
            user_id=user_id,
            activity_type=service.service_type,
            details={
                'action': 'use_service',
                'service_name': service.service_type,
                'fee': float(service.fee)
            }
        )

        db.session.commit()
        return jsonify({"message": "Service used successfully", "balance": data_user.balance}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


#=======获取服务费===========================
@datauser_bp.route('/api/service_fee')
def get_service_fee():
    try:
        service_type = request.args.get('service_type')
        workspace_id = request.args.get('workspace_id')
        user_id = request.args.get('id')

        data_user = DataUser.query.get(user_id)
        if not data_user:
            return jsonify({'success': False, 'msg': '用户不存在'})

        service = Service.query.filter_by(service_type=service_type, workspace_id=workspace_id).first()
        if not service:
            return jsonify({'success': False, 'msg': '服务不存在'})

        return jsonify({
            'success': True,
            'fee': float(service.fee),
            'paidByOrg': float(data_user.balance) >= float(service.fee)
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'msg': f'服务器内部错误: {str(e)}'})

#=================确认支付======================

@datauser_bp.route('/api/confirm_payment', methods=['POST'])
def confirm_payment():
    try:
        print("Starting payment confirmation process...")  # Debug log
        data = request.json
        print("Received payment data:", data)  # Debug log
        
        service_type = data['service_type']
        user = DataUser.query.get(data['user_id'])
        if not user:
            print("User not found:", data['user_id'])  # Debug log
            return jsonify({'success': False, 'msg': '用户不存在'})
            
        service = Service.query.filter_by(service_type=data['service_type'], workspace_id=data['workspace_id']).first()
        if not service:
            print("Service not found:", data['service_type'])  # Debug log
            return jsonify({'success': False, 'msg': '服务不存在'})
            
        fee = float(service.fee)
        print(f"Service fee: {fee}, User balance: {user.balance}")  # Debug log

        if float(user.balance) < fee:
            print("Insufficient balance")  # Debug log
            return jsonify({'success': False, 'msg': '余额不足'})

        try:
            # 创建支付记录
            payment_record = PaymentRecord(
                user_id=user.id,
                amount=fee,
                payment_method=data['method'],
                detail=f"{service_type} - {data.get('thesis_title', '')}"
            )
            print("Created payment record:", payment_record.__dict__)  # Debug log
            db.session.add(payment_record)
            
            # Log the activity
            log_activity(
                workspace_id=user.workspace_id,
                user_id=user.id,
                activity_type='payment',
                details={
                    'action': 'confirm_payment',
                    'service_type': service_type,
                    'amount': fee,
                    'payment_method': data['method'],
                    'payment_record_id': payment_record.id
                }
            )
            
            # 记录活动日志
            activity_log = ActivityLog(
                workspace_id=user.workspace_id,
                user_id=user.id,
                activity_type='service_access',
                details={
                    'service': data['service_type'],
                    'payment_record_id': payment_record.id
                }
            )
            db.session.add(activity_log)
            
            # 扣除用户余额
            user.balance = float(user.balance) - fee
            print(f"Updated user balance: {user.balance}")  # Debug log
            
            # 提交事务
            db.session.commit()
            print("Transaction committed successfully")  # Debug log
            
            return jsonify({
                'success': True,
                'payment_record_id': payment_record.id,
                'redirect_url': f"/dataUser_dashBorad/payment.html?payment_id={payment_record.id}&service_type={data['service_type']}&workspace_id={data['workspace_id']}&id={user.id}"
            })
        except Exception as e:
            print("Error during transaction:", str(e))  # Debug log
            db.session.rollback()
            raise e
            
    except Exception as e:
        print("Payment confirmation error:", str(e))  # Debug log
        traceback.print_exc()
        return jsonify({'success': False, 'msg': f'服务器内部错误: {str(e)}'})


@datauser_bp.route('/api/datauser/<int:user_id>/balance')
def get_user_balance(user_id):
    try:
        data_user = DataUser.query.get(user_id)
        if not data_user:
            return jsonify({'success': False, 'msg': '用户不存在'})
        
        return jsonify({
            'success': True,
            'balance': float(data_user.balance)
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'msg': f'获取余额失败: {str(e)}'})

@datauser_bp.route('/api/private/course_stats')
@login_required
def get_course_stats():
    try:
        user_id = request.args.get('user_id')
        if not user_id:
            return jsonify({'error': 'Missing user ID'}), 400

        # 获取课程统计信息
        # 从数据库获取实际的课程数量
        active_courses = db.session.query(func.count(Course.id)).filter(
            Course.user_id == user_id,
            Course.is_active == True
        ).scalar() or 0

        stats = {
            'active_courses': active_courses,
            'shared_items': active_courses  # 使用课程数量作为共享项数量
        }
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@datauser_bp.route('/api/private/service_stats')
@login_required
def get_service_stats():
    try:
        user_id = request.args.get('user_id')
        if not user_id:
            return jsonify({'error': 'Missing user ID'}), 400

        # 获取服务统计信息
        data_user = DataUser.query.get(user_id)
        if not data_user:
            return jsonify({'error': 'User not found'}), 404

        # 获取活跃服务数量
        active_services = Service.query.filter_by(
            workspace_id=data_user.workspace_id,
            is_active=True
        ).count()

        # 获取访问日志数量
        access_logs = ActivityLog.query.filter_by(
            workspace_id=data_user.workspace_id,
            user_id=user_id
        ).count()

        return jsonify({
            'active_services': active_services,
            'access_logs': access_logs
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@datauser_bp.route('/dataUser_dashBorad/thesis_search.html')
def thesis_search_page():
    return render_template('dataUser_dashBorad/thesis_search.html')

@datauser_bp.route('/api/datauser/<int:user_id>/available_services')
@login_required
def get_available_services(user_id):
    try:
        data_user = DataUser.query.get(user_id)
        if not data_user:
            return jsonify({'success': False, 'msg': 'User not found'}), 404

        # Get all active services for the workspace
        services = Service.query.filter_by(
            workspace_id=data_user.workspace_id,
            is_active=True
        ).all()

        # Get API configurations for this workspace
        api_configs = {
            config.service_type: config 
            for config in APIConfig.query.filter_by(workspace_id=data_user.workspace_id).all()
        }

        # Combine service info with API config status
        service_info = []
        for service in services:
            service_dict = service.to_dict()
            # Only check API configuration for private data providers (access_right = 3)
            if data_user.access_rights == 3:
                if service.service_type == 'thesis_sharing':
                    # For thesis sharing, check both search and download configurations
                    service_dict['api_configured'] = ('thesis_search' in api_configs and 
                                                    'thesis_download' in api_configs)
                else:
                    service_dict['api_configured'] = service.service_type in api_configs
            else:
                # For other users, services are considered configured by default
                service_dict['api_configured'] = True
            
            service_info.append(service_dict)

        return jsonify({
            'success': True,
            'services': service_info
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'msg': f'Error: {str(e)}'}), 500

@datauser_bp.route('/api/check_service_config')
@login_required
def check_service_config():
    try:
        workspace_id = request.args.get('workspace_id')
        service_type = request.args.get('service_type')
        user_id = request.args.get('user_id')
        
        if not all([workspace_id, service_type, user_id]):
            return jsonify({'success': False, 'msg': 'Missing parameters'}), 400

        # Get user's access rights
        data_user = DataUser.query.get(user_id)
        if not data_user:
            return jsonify({'success': False, 'msg': 'User not found'}), 404

        # Check if service exists and is active
        service = Service.query.filter_by(
            workspace_id=workspace_id,
            is_active=True
        ).first()

        if not service:
            return jsonify({
                'success': False,
                'msg': 'Service is not available in your workspace'
            })

        # Only check API configuration for private data providers
        if data_user.access_rights == 3:
            # Check if API is configured
            api_config = APIConfig.query.filter_by(
                workspace_id=workspace_id,
                service_type=service_type
            ).first()

            if not api_config:
                return jsonify({
                    'success': False,
                    'msg': 'Service is not configured yet. Please contact your administrator.'
                })

        return jsonify({
            'success': True,
            'msg': 'Service is available and configured'
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'msg': f'Error: {str(e)}'}), 500

@datauser_bp.route('/api/policies')
def get_policies():
    try:
        policies = Policy.query.filter_by(is_active=True).all()
        if not policies:
            return jsonify({
                'success': True,
                'policies': [],
                'message': 'No policies found'
            })
        return jsonify({
            'success': True,
            'policies': [policy.to_dict() for policy in policies]
        })
    except Exception as e:
        print(f"Error in get_policies: {str(e)}")  # Add logging
        return jsonify({
            'success': False,
            'msg': f'Error retrieving policies: {str(e)}'
        }), 500

@datauser_bp.route('/api/policy/<policy_type>')
def get_policy_detail(policy_type):
    try:
        policy = Policy.query.filter_by(type=policy_type, is_active=True).first()
        if not policy:
            return jsonify({
                'success': False,
                'msg': 'Policy not found'
            }), 404
        return jsonify({
            'success': True,
            'policy': policy.to_dict()
        })
    except Exception as e:
        print(f"Error in get_policy_detail: {str(e)}")  # Add logging
        return jsonify({
            'success': False,
            'msg': f'Error retrieving policy details: {str(e)}'
        }), 500

@datauser_bp.route('/dataUser_dashBorad/browse-policies.html')
def browse_policies():
    return render_template('dataUser_dashBorad/browse-policies.html')

@datauser_bp.route('/dataUser_dashBorad/policy-detail.html')
def policy_detail():
    return render_template('dataUser_dashBorad/policy-detail.html')

@datauser_bp.route('/dataUser_dashBorad/seek-help.html')
def seek_help():
    user_id = request.args.get('id')
    if not user_id:
        return "User ID is required", 400
        
    # Get all questions for this user
    questions = Question.query.filter_by(user_id=user_id).all()
    return render_template('dataUser_dashBorad/seek-help.html', 
                         questions=questions, 
                         user_id=user_id)

@datauser_bp.route('/api/payment-records')
@login_required
def get_payment_records():
    try:
        print("Starting get_payment_records...")  # Debug log
        user_id = request.args.get('id')
        print(f"Received user_id: {user_id}")  # Debug log
        
        if not user_id:
            print("Error: Missing user ID")  # Debug log
            return jsonify({'error': 'Missing user ID'}), 400

        # 获取O-Convener的workspace_id
        o_convener = OConvener.query.get(user_id)
        print(f"Found O-Convener: {o_convener}")  # Debug log
        
        if not o_convener:
            print(f"Error: O-Convener not found for ID {user_id}")  # Debug log
            return jsonify({'error': 'O-Convener not found'}), 404

        workspace_id = o_convener.workspace_id
        print(f"Workspace ID: {workspace_id}")  # Debug log

        try:
            # 获取该workspace的所有支付记录，并关联users表获取用户信息
            payment_records = db.session.query(
                PaymentRecord,
                users.user_name.label('user_name'),
                users.email.label('user_email')
            ).join(
                DataUser,
                PaymentRecord.user_id == DataUser.id
            ).join(
                users,
                DataUser.id == users.id
            ).filter(
                DataUser.workspace_id == workspace_id
            ).order_by(
                PaymentRecord.payment_date.desc()
            ).all()
            
            print(f"Found {len(payment_records)} payment records")  # Debug log

            # 格式化记录
            records = []
            for record, user_name, user_email in payment_records:
                try:
                    formatted_record = {
                        'id': record.id,
                        'user_id': record.user_id,
                        'user_name': user_name,
                        'user_email': user_email,
                        'amount': float(record.amount),
                        'payment_method': record.payment_method,
                        'detail': record.detail,
                        'payment_date': record.payment_date.strftime('%Y-%m-%d %H:%M:%S')
                    }
                    records.append(formatted_record)
                except Exception as e:
                    print(f"Error formatting record {record.id}: {str(e)}")  # Debug log
                    continue

            print(f"Successfully formatted {len(records)} records")  # Debug log
            return jsonify(records)

        except Exception as e:
            print(f"Database query error: {str(e)}")  # Debug log
            traceback.print_exc()
            return jsonify({'error': f'Database error: {str(e)}'}), 500

    except Exception as e:
        print(f"General error in get_payment_records: {str(e)}")  # Debug log
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@datauser_bp.route('/workspace/PaymentManagement.html')
def payment_management_page():
    return render_template('workspace/PaymentManagement.html')

@datauser_bp.route('/workspace/settingAccount')
def setting_account_page():
    return render_template('workspace/settingAccount.html')

@datauser_bp.route('/api/bank-accounts', methods=['POST'])
@login_required
def create_bank_account():
    try:
        data = request.json
        print("Received bank account data:", data)  # Debug log
        
        # 验证必要字段
        required_fields = ['bank', 'account_name', 'account_number', 'workspace_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400

        # 创建新的银行账户记录
        new_account = BankAccount(
            workspace_id=data['workspace_id'],
            bank=data['bank'],
            account_number=data['account_number'],
            account_name=data['account_name'],
            balance=0.0  # 初始余额为0
        )

        db.session.add(new_account)
        db.session.commit()

        print("Bank account created successfully:", new_account.id)  # Debug log
        return jsonify({'success': True, 'message': 'Bank account created successfully'})

    except Exception as e:
        print("Error creating bank account:", str(e))  # Debug log
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@datauser_bp.route('/api/api-config')
@login_required
def get_api_config():
    try:
        workspace_id = request.args.get('workspace_id')
        service_type = request.args.get('service_type')
        
        if not all([workspace_id, service_type]):
            return jsonify({'error': 'Missing required parameters'}), 400

        config = APIConfig.query.filter_by(
            workspace_id=workspace_id,
            service_type=service_type
        ).first()

        if not config:
            return jsonify({'error': 'API configuration not found'}), 404

        return jsonify({
            'base_url': config.base_url,
            'path': config.path,
            'method': config.method
        })

    except Exception as e:
        print("Error getting API config:", str(e))  # Debug log
        return jsonify({'error': str(e)}), 500

