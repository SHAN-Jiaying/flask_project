from flask import Blueprint, render_template, request, jsonify, abort, flash, redirect, url_for
from flask_login import login_required, current_user
import requests

from models.workspace import Question, ActivityLog, SystemBankAccount, APIConfig, MembershipPricing, UserNotification
from models.user import db, users, EAdmin, OConvener,RegistrationApplication
from werkzeug.security import generate_password_hash
import pandas as pd
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/t-Admin/help-request-answer.html')
def help_requests():
    user_id = request.args.get('id')
    if not user_id:
        return "User ID is required", 400
        
    questions = Question.query.filter_by(state='unanswered').all()
    return render_template('t-Admin/help-request-answer.html', 
                         questions=questions, 
                         user_id=user_id)

@admin_bp.route('/answer-question', methods=['POST'])
def answer_question():
    try:
        data = request.get_json()
        question = Question.query.get_or_404(data['question_id'])
        question.answer = data['answer']
        question.state = 'answered'
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@admin_bp.route('/t-Admin/t-admin-main.html')
def admin_main():
    user_id = request.args.get('id')
    if not user_id:
        return "User ID is required", 400
    return render_template('t-Admin/t-admin-main.html', user_id=user_id)

@admin_bp.route('/t-Admin/e-admin-account-manage.html')
def manage_eadmin():
    user_id = request.args.get('id')
    if not user_id:
        return "User ID is required", 400

    # 获取所有E-Admin和SE-Admin用户
    admins = users.query.filter(users.role.in_(['E-Admin', 'SE-Admin'])).all()
    return render_template('t-Admin/e-admin-account-manage.html', admins=admins, user_id=user_id)

@admin_bp.route('/t-Admin/info-edit-page.html')
def edit_admin():
    user_id = request.args.get('id')
    admin_id = request.args.get('admin_id')
    if not user_id or not admin_id:
        return "User ID and Admin ID are required", 400

    admin = users.query.get_or_404(admin_id)
    return render_template('t-Admin/info-edit-page.html', admin=admin, user_id=user_id)

@admin_bp.route('/api/update-admin', methods=['POST'])
def update_admin():
    try:
        data = request.get_json()
        admin = users.query.get_or_404(data['admin_id'])
        
        admin.user_name = data['name']
        admin.email = data['email']
        if data.get('password'):
            admin.password = generate_password_hash(data['password'])
            
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@admin_bp.route('/api/upload-admin-excel', methods=['POST'])
def upload_admin_excel():
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file uploaded'}), 400

        file = request.files['file']
        if not file.filename.endswith('.xlsx'):
            return jsonify({'success': False, 'error': 'File must be .xlsx format'}), 400

        # 读取Excel文件
        df = pd.read_excel(file)
        required_columns = ['name', 'email', 'password', 'role']
        if not all(col in df.columns for col in required_columns):
            return jsonify({'success': False, 'error': 'Missing required columns'}), 400

        # 处理每一行数据
        for _, row in df.iterrows():
            if row['role'] not in ['E-Admin', 'SE-Admin']:
                continue

            # 检查邮箱是否已存在
            if users.query.filter_by(email=row['email']).first():
                continue

            new_user = users(
                email=row['email'],
                user_name=row['name'],
                password=generate_password_hash(str(row['password'])),
                role=row['role']
            )
            db.session.add(new_user)

            # 如果是E-Admin，创建对应的EAdmin记录
            if row['role'] == 'E-Admin':
                new_eadmin = EAdmin(id=new_user.id)
                db.session.add(new_eadmin)

        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@admin_bp.route('/question-detail/<int:question_id>')
def question_detail():
    question = Question.query.get_or_404(question_id)
    return render_template('t-Admin/question-detail.html', question=question)

@admin_bp.route('/E_Admin/System_Log_Check_Page.html')
def system_log_check():
    try:
        user_id = request.args.get('id')
        workspace_id = request.args.get('workspace_id')
        
        if not user_id or not workspace_id:
            abort(400, "Missing user ID or workspace ID")

        # Get the user
        user = users.query.get(user_id)
        if not user:
            abort(404, "User not found")

        # Verify the user is an E-Admin
        if user.role != 'E-Admin':
            abort(403, "Unauthorized access - Not an E-Admin")

        # Get activity logs for the workspace
        logs = ActivityLog.query.filter_by(workspace_id=workspace_id).order_by(ActivityLog.timestamp.desc()).all()

        return render_template('E_Admin/System_Log_Check_Page.html',
                             user_id=user_id,
                             logs=logs)

    except Exception as e:
        print(f"Error in system_log_check: {str(e)}")
        abort(500, "Internal server error")

@admin_bp.route('/E_Admin/verify_bank_account', methods=['POST'])
def verify_bank_account():
    try:
        data = request.get_json()
        name = data.get('name')
        account = data.get('account')
        bank = data.get('bank')
        password = data.get('password')

        if not all([name, account, bank, password]):
            return jsonify({'status': 'fail', 'message': 'Missing required fields'}), 400

        # 获取API配置
        api_config = APIConfig.query.filter_by(service_type='bank_account_auth').first()
        if not api_config:
            return jsonify({'status': 'fail', 'message': 'API configuration not found'}), 500

        # 构建请求URL
        url = f"{api_config.base_url}{api_config.path}"

        # 准备请求数据
        request_data = {
            "bank": bank,
            "account_name": name,
            "account_number": account,
            "password": password
        }

        try:
            # 发送验证请求
            response = requests.post(url, json=request_data, timeout=10)
            response.raise_for_status()  # 检查HTTP错误
            
            result = response.json()
            return jsonify(result)
        except requests.RequestException as e:
            print(f"API request error: {str(e)}")  # 添加日志
            return jsonify({'status': 'fail', 'message': f'Verification service error: {str(e)}'}), 500

    except Exception as e:
        print(f"Verification error: {str(e)}")  # 添加日志
        return jsonify({'status': 'fail', 'message': str(e)}), 500

@admin_bp.route('/E_Admin/add_system_bank_account', methods=['GET', 'POST'])
def add_system_bank_account():
    if request.method == 'GET':
        user_id = request.args.get('id')
        if not user_id:
            abort(400, "Missing user ID")
        return render_template('E_Admin/add_bank_account.html', user_id=user_id)
    
    elif request.method == 'POST':
        try:
            user_id = request.form.get('user_id')
            if not user_id:
                abort(400, "Missing user ID")

            # Verify the user is an E-Admin
            user = users.query.get(user_id)
            if not user or user.role != 'E-Admin':
                abort(403, "Unauthorized access - Not an E-Admin")

            # Get form data
            name = request.form.get('name')
            account = request.form.get('account')
            bank = request.form.get('bank')

            # Validate required fields
            if not all([name, account, bank]):
                abort(400, "All fields are required")

            # Check if account number already exists
            if SystemBankAccount.query.filter_by(account=account).first():
                abort(400, "Account number already exists")

            # Create new system bank account
            new_account = SystemBankAccount(
                name=name,
                account=account,
                bank=bank
            )

            db.session.add(new_account)
            db.session.commit()

            flash('System bank account created successfully', 'success')
            return redirect(f'/E_Admin/edba_bank.html?id={user_id}')

        except Exception as e:
            db.session.rollback()
            flash(f'Error creating account: {str(e)}', 'danger')
            return redirect(f'/E_Admin/add_bank_account.html?id={user_id}')

@admin_bp.route('/E_Admin/edba_bank.html')
def edba_bank():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")

    # Verify the user is an E-Admin
    user = users.query.get(user_id)
    if not user or user.role != 'E-Admin':
        abort(403, "Unauthorized access - Not an E-Admin")

    # Get all system bank accounts
    bank_accounts = SystemBankAccount.query.all()
    
    return render_template('E_Admin/edba_bank.html',
                         user_id=user_id,
                         bank_accounts=bank_accounts)

@admin_bp.route('/E_Admin/delete_system_bank_account/<int:account_id>', methods=['POST'])
def delete_system_bank_account(account_id):
    try:
        user_id = request.form.get('user_id')
        if not user_id:
            abort(400, "Missing user ID")

        # Verify the user is an E-Admin
        user = users.query.get(user_id)
        if not user or user.role != 'E-Admin':
            abort(403, "Unauthorized access - Not an E-Admin")

        # Get and delete the account
        account = SystemBankAccount.query.get_or_404(account_id)
        db.session.delete(account)
        db.session.commit()

        flash('Bank account deleted successfully', 'success')
        return redirect(f'/E_Admin/edba_bank.html?id={user_id}')

    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting account: {str(e)}', 'danger')
        return redirect(f'/E_Admin/edba_bank.html?id={user_id}')

@admin_bp.route('/E_Admin/memberfeeSetting.html')
def member_fee_settings():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")

    # Verify the user is an E-Admin
    user = users.query.get(user_id)
    if not user or user.role != 'E-Admin':
        abort(403, "Unauthorized access - Not an E-Admin")

    # Get all membership pricing records
    membership_pricing = MembershipPricing.query.all()
    
    return render_template('E_Admin/memberfeeSetting.html',
                         user_id=user_id,
                         membership_pricing=membership_pricing)

@admin_bp.route('/E_Admin/update_membership_fee', methods=['POST'])
def update_membership_fee():
    try:
        user_id = request.form.get('user_id')
        if not user_id:
            abort(400, "Missing user ID")

        # Verify the user is an E-Admin
        user = users.query.get(user_id)
        if not user or user.role != 'E-Admin':
            abort(403, "Unauthorized access - Not an E-Admin")

        pricing_id = request.form.get('pricing_id')
        access_right = request.form.get('access_right')
        price = request.form.get('price')

        if not all([pricing_id, access_right, price]):
            flash('All fields are required', 'danger')
            return redirect(f'/E_Admin/memberfeeSetting.html?id={user_id}')

        # Update the pricing record
        pricing = MembershipPricing.query.get_or_404(pricing_id)
        pricing.access_right = int(access_right)
        pricing.price = float(price)

        db.session.commit()
        flash('Membership fee updated successfully', 'success')
        return redirect(f'/E_Admin/memberfeeSetting.html?id={user_id}')

    except Exception as e:
        db.session.rollback()
        flash(f'Error updating membership fee: {str(e)}', 'danger')
        return redirect(f'/E_Admin/memberfeeSetting.html?id={user_id}')

@admin_bp.route('/user.html')
def user_dashboard():
    if not current_user.is_authenticated:
        return redirect(url_for('login'))
    
    try:
        # 获取用户的所有通知，按时间倒序排列
        notifications = UserNotification.query.filter_by(user_id=current_user.id)\
            .order_by(UserNotification.created_at.desc()).all()
        
        # 添加调试日志
        print(f"Found {len(notifications)} notifications for user {current_user.id}")
        for notification in notifications:
            print(f"Notification: {notification.id}, Subject: {notification.subject}, Read: {notification.is_read}")
        
        return render_template('user.html', 
                             notifications=notifications,
                             current_user=current_user)
    except Exception as e:
        print(f"Error in user_dashboard: {str(e)}")
        return render_template('user.html', 
                             notifications=[],
                             current_user=current_user)

@admin_bp.route('/api/create_notification', methods=['POST'])
def create_notification():
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        subject = data.get('subject')
        message = data.get('message')

        if not all([user_id, subject, message]):
            return jsonify({'success': False, 'message': 'Missing required fields'}), 400

        # 创建新通知
        notification = UserNotification(
            user_id=user_id,
            subject=subject,
            message=message
        )

        db.session.add(notification)
        db.session.commit()

        return jsonify({
            'success': True,
            'message': 'Notification created successfully',
            'notification': notification.to_dict()
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/api/mark_notification_read/<int:notification_id>', methods=['POST'])
def mark_notification_read(notification_id):
    try:
        notification = UserNotification.query.get_or_404(notification_id)
        
        # 确保只能修改自己的通知
        if notification.user_id != current_user.id:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403

        notification.is_read = True
        db.session.commit()

        return jsonify({'success': True, 'message': 'Notification marked as read'})

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/api/get_notifications')
def get_notifications():
    try:
        if not current_user.is_authenticated:
            return jsonify({'success': False, 'message': 'Not authenticated'}), 401

        notifications = UserNotification.query.filter_by(user_id=current_user.id)\
            .order_by(UserNotification.created_at.desc()).all()

        return jsonify({
            'success': True,
            'notifications': [n.to_dict() for n in notifications]
        })

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/E_Admin/application_list_page.html')
def application_list():
    try:
        user_id = request.args.get('id')
        if not user_id:
            abort(400, "Missing user ID")

        # 验证用户是否为E-Admin
        user = users.query.get(user_id)
        if not user or user.role != 'E-Admin':
            abort(403, "Unauthorized access - Not an E-Admin")

        # 获取所有申请记录，按提交时间倒序排列
        applications = RegistrationApplication.query.order_by(
            RegistrationApplication.submission_time.desc()
        ).all()
        
        # 添加调试日志
        print(f"Found {len(applications)} applications")
        for app in applications:
            print(f"Application: {app.application_id}, Status: {app.status}, Organization: {app.organization_full_name}")
        
        # 确保applications不为None
        if applications is None:
            applications = []
            
        return render_template('E_Admin/application_list_page.html',
                             user_id=user_id,
                             applications=applications)
    except Exception as e:
        print(f"Error in application_list: {str(e)}")
        abort(500, str(e))

@admin_bp.route('/E_Admin/se-admin-dashboard.html')
def se_admin_dashboard():
    user_id = request.args.get('id')
    if not user_id:
        abort(400, "Missing user ID")

    # Verify the user is a Senior E-Admin
    user = users.query.get(user_id)
    if not user or user.role != 'SE-Admin':
        abort(403, "Unauthorized access - Not a Senior E-Admin")

    return render_template('E_Admin/se-admin-dashboard.html', user_id=user_id)




