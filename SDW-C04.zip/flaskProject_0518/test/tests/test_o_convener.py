import unittest
from unittest.mock import patch

from app import app
import json
from classes.OConvener import OConvener,MemberList,Service



import unittest

class TestOConvener(unittest.TestCase):

    def setUp(self):
        # 创建 OConvener 实例，用于测试
        self.convener = OConvener('OrgName', 'ON', 'test@example.com', 'workspace123', 'bank123')
        # 添加测试成员到列表
        self.convener.membership_list.add_member("valid.email@example.com", 2)

    # White-box_Test
    def test_remove_member_valid_email_found(self):
        # 测试有效电子邮件，成员存在，成功移除
        with patch("builtins.print") as mock_print:
            result = self.convener.remove_member_from_list("valid.email@example.com")
            self.assertTrue(result)  # 成员成功移除，应该返回 True
            mock_print.assert_called_with("Member valid.email@example.com removed.")

    def test_remove_member_valid_email_not_found(self):
        # 测试有效电子邮件，成员不存在
        with patch("builtins.print") as mock_print:
            result = self.convener.remove_member_from_list("nonexistent@example.com")
            self.assertFalse(result)  # 成员不存在，应该返回 False
            mock_print.assert_called_with("User nonexistent@example.com does not exist.")

    def test_remove_member_invalid_email(self):
        # 测试无效的电子邮件格式
        with patch("builtins.print") as mock_print:
            result = self.convener.remove_member_from_list("invalid-email")
            self.assertFalse(result)  # 无效电子邮件格式，应该返回 False
            mock_print.assert_called_with("Invalid email format: invalid-email")


    #Equivalence_test

    #test operation
    # submitRegistrationApplication(organizationName: String, organizationShortName: String, email: String, proofDocument: String);

    def test_D1_1_1_valid(self):
        # 测试有效的组织名称、有效电子邮件和有效证明文件
        result = self.convener.submit_registration_application(
            "ValidOrganization", "validshortname", "valid.email@example.com", "valid_proof_document.pdf"
        )
        self.assertTrue(result)  # 假设这个方法会返回 True

    def test_D1_1_2_invalid_proof_document(self):
        # 测试有效的组织名称、有效电子邮件和无效证明文件
        result = self.convener.submit_registration_application(
            "ValidOrganization", "validshortname", "valid.email@example.com", "invalid_proof_document.txt"
        )
        self.assertFalse(result)  # 证明文件无效，应返回 False

    def test_D1_2_1_invalid_email_valid_proof(self):
        # 测试有效的组织名称、无效电子邮件和有效证明文件
        result = self.convener.submit_registration_application(
            "ValidOrganization", "validshortname", "invalid-email", "valid_proof_document.pdf"
        )
        self.assertFalse(result)  # 电子邮件无效，应返回 False

    def test_D1_2_2_invalid_email_invalid_proof(self):
        # 测试有效的组织名称、无效电子邮件和无效证明文件
        result = self.convener.submit_registration_application(
            "ValidOrganization", "validshortname", "invalid-email", "invalid_proof_document.txt"
        )
        self.assertFalse(result)  # 电子邮件和证明文件都无效，应返回 False

    def test_D2_1_1_invalid_organization_valid_email_valid_proof(self):
        # 测试无效的组织名称、有效电子邮件和有效证明文件
        result = self.convener.submit_registration_application(
            "&&4familyGAN", "shortname", "nina.jija@eam.com", "valid_proof_document.pdf"
        )
        self.assertFalse(result)  # 组织名称无效，应返回 False

    def test_D2_1_2_invalid_organization_valid_email_invalid_proof(self):
        # 测试无效的组织名称、有效电子邮件和无效证明文件
        result = self.convener.submit_registration_application(
            "&&4familyGAN", "shortname", "nina.jija@eam.com", "invalid_proof_document.txt"
        )
        self.assertFalse(result)  # 组织名称无效，应返回 False

    def test_D2_2_1_invalid_organization_invalid_email_valid_proof(self):
        # 测试无效的组织名称、无效电子邮件和有效证明文件
        result = self.convener.submit_registration_application(
            "&&4familyGAN", "shortname", "invalid-email", "valid_proof_document.pdf"
        )
        self.assertFalse(result)  # 组织名称和电子邮件都无效，应返回 False

    def test_D2_2_2_invalid_organization_invalid_email_invalid_proof(self):
        # 测试无效的组织名称、无效电子邮件和无效证明文件
        result = self.convener.submit_registration_application(
            "&&4familyGAN", "shortname", "invalid-email", "invalid_proof_document.txt"
        )
        self.assertFalse(result)  # 所有输入都无效，应返回 False

    # test operation addMemberToList(member: Member，int access_right):
    def test_D1_1_1_valid(self):
        # 测试有效电子邮件和有效访问权限
        result = self.convener.add_member_to_list("valid.email@example.com", 2)
        self.assertTrue(result)  # 假设 add_member_to_list 返回 True

    def test_D1_1_2_invalid_access_right(self):
        # 测试有效电子邮件和无效访问权限
        result = self.convener.add_member_to_list("valid.email@example.com", "ad")  # 无效访问权限
        self.assertFalse(result)  # 无效的访问权限，应该返回 False

    def test_D1_2_1_invalid_email_valid_access_right(self):
        # 测试无效电子邮件和有效访问权限
        result = self.convener.add_member_to_list("invalid-email", 2)
        self.assertFalse(result)  # 无效电子邮件，应该返回 False

    def test_D1_2_2_invalid_email_invalid_access_right(self):
        # 测试无效电子邮件和无效访问权限
        result = self.convener.add_member_to_list("invalid-email", 2.5)  # 无效访问权限
        self.assertFalse(result)  # 无效的电子邮件和访问权限，应该返回 False

if __name__ == '__main__':
    unittest.main()


